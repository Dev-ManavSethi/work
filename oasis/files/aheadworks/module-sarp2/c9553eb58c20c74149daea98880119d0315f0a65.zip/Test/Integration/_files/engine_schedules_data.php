<?php
/**
 * Copyright 2019 aheadWorks. All rights reserved.
See LICENSE.txt for license details.
 */


return [
    [4, 7, 'day', 1, 1, 1, 5, 0, 10, '{"token_id":"5"}', 0],
    [5, 8, 'week', 1, 1, 1, 5, 0, 10, '{"token_id":"5"}', 0],
    [6, 9, 'month', 1, 1, 1, 5, 0, 10, '{"token_id":"5"}', 0],
    [7, 10, 'day', 1, 1, 1, 5, 0, 10, '{"token_id":"6"}', 0],
    [8, 11, 'day', 1, 1, 0, 0, 1, 10, '{"token_id":"6"}', 0],
    [9, 12, 'day', 1, 0, 0, 0, 1, 10, '{"token_id":"6"}', 0]
];
