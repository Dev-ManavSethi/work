<?php

namespace MagicToolbox\Sirv\Model\View\Asset;

/**
 * Image file asset
 *
 */
class SirvImage implements \Magento\Framework\View\Asset\LocalInterface
{
    /**
     * File path
     *
     * @var string
     */
    protected $filePath;

    /**
     * Image type (thumbnail, small_image, image, swatch_image, swatch_thumb)
     *
     * @var string
     */
    protected $sourceContentType;

    /**
     * Default image type
     *
     * @var string
     */
    protected $contentType = 'image';

    /**
     * Context interface
     *
     * @var \Magento\Framework\View\Asset\ContextInterface
     */
    protected $context;

    /**
     * Misc image params
     *
     * @var array
     */
    protected $miscParams;

    /**
     * Config interface
     *
     * @var \Magento\Catalog\Model\Product\Media\ConfigInterface
     */
    protected $mediaConfig;

    /**
     * Encryptor interface
     *
     * @var \Magento\Framework\Encryption\EncryptorInterface
     */
    protected $encryptor;

    /**
     * Base media path
     *
     * @var string
     */
    protected $baseMediaPath;

    /**
     * Determine if the data has been initialized or not
     *
     * @var bool
     */
    protected static $isInitialized = false;

    /**
     * Is Sirv enabled flag
     *
     * @var bool
     */
    protected static $isSirvEnabled = false;

    /**
     * Image factory
     *
     * @var \Magento\Framework\Image\Factory
     */
    protected static $imageFactory;

    /**
     * Sirv adapter
     *
     * @var \MagicToolbox\Sirv\Model\Adapter\S3
     */
    protected static $sirvAdapter = null;

    /**
     * @var \Magento\Framework\Filesystem\Directory\WriteInterface
     */
    protected static $mediaDirectory;

    /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected static $storeManager;

    /**
     * @var \Magento\Framework\View\FileSystem
     */
    protected static $viewFileSystem;

    /**
     * Image constructor
     *
     * @param \Magento\Catalog\Model\Product\Media\ConfigInterface $mediaConfig
     * @param \Magento\Framework\View\Asset\ContextInterface $context
     * @param \Magento\Framework\Encryption\EncryptorInterface $encryptor
     * @param string $filePath
     * @param array $miscParams
     */
    public function __construct(
        \Magento\Catalog\Model\Product\Media\ConfigInterface $mediaConfig,
        \Magento\Framework\View\Asset\ContextInterface $context,
        \Magento\Framework\Encryption\EncryptorInterface $encryptor,
        $filePath,
        array $miscParams = []
    ) {
        if (isset($miscParams['image_type'])) {
            $this->sourceContentType = $miscParams['image_type'];
            unset($miscParams['image_type']);
        } else {
            $this->sourceContentType = $this->contentType;
        }
        $this->mediaConfig = $mediaConfig;
        $this->context = $context;
        $this->filePath = $filePath;
        $this->miscParams = $miscParams;
        $this->encryptor = $encryptor;
        $this->baseMediaPath = $mediaConfig->getBaseMediaPath();
        if (static::$isInitialized === false) {
            $this->initializeData();
        }
    }

    /**
     * Initialize the data
     *
     * @return void
     */
    protected function initializeData()
    {
        static::$isInitialized = true;
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $helper = $objectManager->get(\MagicToolbox\Sirv\Helper\Data::class);
        static::$isSirvEnabled = $helper->isSirvEnabled();
        static::$imageFactory = $objectManager->get(\Magento\Framework\Image\Factory::class);
        static::$sirvAdapter = $objectManager->get(\MagicToolbox\Sirv\Model\Adapter\S3::class);
        $filesystem = $objectManager->get(\Magento\Framework\Filesystem::class);
        static::$mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        static::$storeManager = $objectManager->get(\Magento\Store\Model\StoreManager::class);
        static::$viewFileSystem = $objectManager->get(\Magento\Framework\View\FileSystem::class);
    }

    /**
     * Get absolute watermark file path or false if the file is not found
     *
     * @param string $watermarkFile
     * @return string | bool
     */
    protected function getWatermarkFilePath($watermarkFile)
    {
        $filePath = false;

        $candidates = [
            $this->baseMediaPath . '/watermark/stores/' . static::$storeManager->getStore()->getId() . $watermarkFile,
            $this->baseMediaPath . '/watermark/websites/' . static::$storeManager->getWebsite()->getId() . $watermarkFile,
            $this->baseMediaPath . '/watermark/default/' . $watermarkFile,
            $this->baseMediaPath . '/watermark/' . $watermarkFile,
        ];
        foreach ($candidates as $candidate) {
            if (static::$mediaDirectory->isExist($candidate)) {
                $filePath = static::$mediaDirectory->getAbsolutePath($candidate);
                break;
            }
        }

        if (!$filePath) {
            $filePath = static::$viewFileSystem->getStaticFileName($watermarkFile);
        }

        return $filePath;
    }

    /**
     * Get resource URL
     *
     * @return string
     */
    public function getUrl()
    {
        if (!static::$isSirvEnabled) {
            return $this->context->getBaseUrl() . DIRECTORY_SEPARATOR . $this->getRelativePath();
        }

        //NOTE: path relative to the media folder
        $originalImagePath = $this->getSourceFile();

        //NOTE: absolute file path
        $absolutePath = static::$mediaDirectory->getAbsolutePath($originalImagePath);

        /** @var \MagicToolbox\Sirv\Model\Image */
        $imageProcessor = static::$imageFactory->create($absolutePath);

        if (isset($this->miscParams['keep_aspect_ratio'])) {
            $imageProcessor->keepAspectRatio($this->miscParams['keep_aspect_ratio']);
        }
        if (isset($this->miscParams['keep_frame'])) {
            $imageProcessor->keepFrame($this->miscParams['keep_frame']);
        }
        if (isset($this->miscParams['keep_transparency'])) {
            $imageProcessor->keepTransparency($this->miscParams['keep_transparency']);
        }
        if (isset($this->miscParams['constrain_only'])) {
            $imageProcessor->constrainOnly($this->miscParams['constrain_only']);
        }
        if (isset($this->miscParams['background'])) {
            $imageProcessor->backgroundColor($this->miscParams['background']);
        }
        if (isset($this->miscParams['quality'])) {
            $imageProcessor->quality($this->miscParams['quality']);
        }
        if (isset($this->miscParams['watermark_file'])) {
            $watermarkFile = $this->getWatermarkFilePath($this->miscParams['watermark_file']);
            if ($watermarkFile) {
                $imageProcessor->watermark($watermarkFile);
                $imageProcessor->setWatermarkPosition($this->miscParams['watermark_position']);
                $imageProcessor->setWatermarkImageOpacity($this->miscParams['watermark_image_opacity']);
                $imageProcessor->setWatermarkWidth($this->miscParams['watermark_width']);
                $imageProcessor->setWatermarkHeight($this->miscParams['watermark_height']);
            }
        }

        $width = isset($this->miscParams['image_width']) ? $this->miscParams['image_width'] : null;
        $height = isset($this->miscParams['image_height']) ? $this->miscParams['image_height'] : null;
        if ($width || $height) {
            $imageProcessor->resize($width, $height);
        }

        if (isset($this->miscParams['angle'])) {
            $imageProcessor->rotate($this->miscParams['angle']);
        }

        $imageProcessor->save($absolutePath);

        $url = static::$sirvAdapter->getUrl($originalImagePath);
        $url .= $imageProcessor->getImagingOptionsQuery();

        return $url;
    }

    /**
     * Get type of contents
     *
     * @return string
     */
    public function getContentType()
    {
        return $this->contentType;
    }

    /**
     * Get a "context" path to the asset file
     *
     * @return string
     */
    public function getPath()
    {
        return $this->context->getPath() . DIRECTORY_SEPARATOR . $this->getRelativePath();
    }

    /**
     * Get absolute path to original source file
     *
     *
     * @return string
     */
    public function getSourceFile()
    {
        return $this->baseMediaPath . DIRECTORY_SEPARATOR . ltrim($this->getFilePath(), DIRECTORY_SEPARATOR);
    }

    /**
     * Get source content type
     *
     * @return string
     */
    public function getSourceContentType()
    {
        return $this->sourceContentType;
    }

    /**
     * Get content of a local asset
     *
     * @return string
     */
    public function getContent()
    {
        return null;
    }

    /**
     * Get an invariant relative path to file
     *
     * @return string
     */
    public function getFilePath()
    {
        return $this->filePath;
    }

    /**
     * Get context of the asset
     *
     * @return \Magento\Framework\View\Asset\ContextInterface
     */
    public function getContext()
    {
        return $this->context;
    }

    /**
     * Get the module context of file path
     *
     * @return string
     */
    public function getModule()
    {
        return 'cache';
    }

    /**
     * Retrieve part of path based on misc params
     *
     * @return string
     */
    protected function getMiscPath()
    {
        return $this->encryptor->hash(
            implode('_', $this->convertToReadableFormat($this->miscParams)),
            \Magento\Framework\Encryption\Encryptor::HASH_VERSION_MD5
        );
    }

    /**
     * Generate relative path
     *
     * @return string
     */
    protected function getRelativePath()
    {
        return preg_replace(
            '#\Q'. DIRECTORY_SEPARATOR . '\E+#',
            DIRECTORY_SEPARATOR,
            $this->getModule() . DIRECTORY_SEPARATOR . $this->getMiscPath() . DIRECTORY_SEPARATOR . $this->getFilePath()
        );
    }

    /**
     * Converting non-string values into a string representation
     *
     * @param array $params
     * @return array
     */
    protected function convertToReadableFormat($params)
    {
        $params['image_height'] = 'h:' . (isset($params['image_height']) ? $params['image_height'] : 'empty');
        $params['image_width'] = 'w:' . (isset($params['image_width']) ? $params['image_width'] :  'empty');
        $params['quality'] = 'q:' . (isset($params['quality']) ? $params['quality'] : 'empty');
        $params['angle'] = 'r:' . (isset($params['angle']) ? $params['angle'] : 'empty');
        $params['keep_aspect_ratio'] = (isset($params['keep_aspect_ratio']) ? '' : 'non') . 'proportional';
        $params['keep_frame'] = (isset($params['keep_frame']) ? '' : 'no') . 'frame';
        $params['keep_transparency'] = (isset($params['keep_transparency']) ? '' : 'no') . 'transparency';
        $params['constrain_only'] = (isset($params['constrain_only']) ? 'do' : 'not') . 'constrainonly';
        if (isset($params['background'])) {
            $params['background'] = 'rgb' . (is_array($params['background']) ? implode(',', $params['background']) : $params['background']);
        } else {
            $params['background'] = 'nobackground';
        }
        return $params;
    }
}
