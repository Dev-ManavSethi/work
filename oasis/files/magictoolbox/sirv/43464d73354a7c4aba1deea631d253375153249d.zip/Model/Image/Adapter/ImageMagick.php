<?php

namespace MagicToolbox\Sirv\Model\Image\Adapter;

class ImageMagick extends \Magento\Framework\Image\Adapter\ImageMagick
{
    /**
     * Sirv adapter
     *
     * @var \MagicToolbox\Sirv\Model\Adapter\S3
     */
    protected $sirvAdapter = null;

    /**
     * Constructor
     *
     * @param \Magento\Framework\Filesystem $filesystem
     * @param \Psr\Log\LoggerInterface $logger
     * @param \MagicToolbox\Sirv\Model\Adapter\S3 $sirvAdapter
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Filesystem $filesystem,
        \Psr\Log\LoggerInterface $logger,
        \MagicToolbox\Sirv\Model\Adapter\S3 $sirvAdapter,
        array $data = []
    ) {
        parent::__construct($filesystem, $logger, $data);
        $this->sirvAdapter = $sirvAdapter;
    }

    /**
     * Save image to specific path.
     * If some folders of path does not exist they will be created
     *
     * @param null|string $destination
     * @param null|string $newName
     * @return void
     * @throws \Exception  If destination path is not writable
     */
    public function save($destination = null, $newName = null)
    {
        $tempFileName = tempnam(sys_get_temp_dir(), 'sirv');
        parent::save($tempFileName);

        //NOTE: prepare destination
        if (empty($destination)) {
            $destination = $this->_fileSrcPath;
        } else {
            if (empty($newName)) {
                $info = pathinfo($destination);
                $newName = $info['basename'];
                $destination = $info['dirname'];
            }
        }

        if (empty($newName)) {
            $newFileName = $this->_fileSrcName;
        } else {
            $newFileName = $newName;
        }
        $fileName = $destination . '/' . $newFileName;

        $this->sirvAdapter->save($fileName, $tempFileName);

        is_file($tempFileName) && is_writable($tempFileName) && unlink($tempFileName);
    }

    /**
     * Checks required dependencies
     *
     * @return void
     * @throws \Exception If some of dependencies are missing
     */
    public function checkDependencies()
    {
        parent::checkDependencies();
        if (!extension_loaded('curl')) {
            throw new \Exception("Required PHP extension 'curl' was not loaded.");
        }
    }
}
