<?php

namespace MagicToolbox\Sirv\Controller\Adminhtml\Settings;

class Save extends \MagicToolbox\Sirv\Controller\Adminhtml\Settings
{
    /**
     * Config helper
     * @var \MagicToolbox\Sirv\Helper\Data
     */
    protected $configHelper = null;

    /**
     * Cache helper
     * @var \MagicToolbox\Sirv\Helper\Cache
     */
    protected $cacheHelper = null;

    /**
     * Sirv adapter factory
     * @var \MagicToolbox\Sirv\Model\Adapter\S3Factory
     */
    protected $s3Factory = null;

    /**
     * Constructor
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \MagicToolbox\Sirv\Helper\Data $configHelper
     * @param \MagicToolbox\Sirv\Helper\Cache $cacheHelper
     * @param \MagicToolbox\Sirv\Model\Adapter\S3Factory $s3Factory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \MagicToolbox\Sirv\Helper\Data $configHelper,
        \MagicToolbox\Sirv\Helper\Cache $cacheHelper,
        \MagicToolbox\Sirv\Model\Adapter\S3Factory $s3Factory
    ) {
        parent::__construct($context, $resultPageFactory);
        $this->configHelper = $configHelper;
        $this->cacheHelper = $cacheHelper;
        $this->s3Factory = $s3Factory;
    }

    /**
     * Save action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        $data = $this->getRequest()->getPostValue();
        $config = isset($data['magictoolbox']) ? (is_array($data['magictoolbox']) ? $data['magictoolbox'] : []) : [];

        if (empty($config)) {
            $this->messageManager->addWarningMessage(__('There is nothing to save!'));
            $resultRedirect->setPath('sirv/*/edit');
            return $resultRedirect;
        }

        $model = $this->configHelper->getConfigModel();
        $collection = $model->getCollection();

        if ($collection->getSize()) {
            foreach ($collection as $item) {
                $name = $item->getData('name');
                if (isset($config[$name])) {
                    $item->setValue($config[$name]);
                    $item->save();
                    unset($config[$name]);
                }
            }
        }

        if (!empty($config)) {
            foreach ($config as $name => $value) {
                $model->clearInstance();
                $model->setData('name', $name);
                $model->setData('value', $value);
                $model->save();
            }
        }

        $this->configHelper->loadConfig();
        $isSirvEnabled = $this->configHelper->isSirvEnabled();
        if ($isSirvEnabled) {
            $sirvAdapter = $this->s3Factory->create([
                'helper' => $this->configHelper,
                'cacheHelper' => $this->cacheHelper
            ]);
            if (!$sirvAdapter->isAuth()) {
                $isSirvEnabled = false;
                $this->messageManager->addNotice(__(
                    'Your Sirv S3 access credentials were rejected. Please check and try again.'
                ));
            }
            if (!$isSirvEnabled) {
                $model->load('enabled', 'name');
                $model->setData('value', 'false');
                $model->save();
            }
        }

        $this->messageManager->addSuccess(__('You saved the settings.'));

        $resultRedirect->setPath('sirv/*/edit');

        return $resultRedirect;
    }
}
