<?php

namespace MagicToolbox\Sirv\Model\Image;

class AdapterFactory extends \Magento\Framework\Image\AdapterFactory
{
    /**
     * @var array
     */
    protected $sirvAdapterMap = [
        'SIRV' => [
            'title' => 'Sirv',
            'class' => 'MagicToolbox\Sirv\Model\Image\Adapter\Sirv'
        ],
        'SIRV-GD2' => [
            'title' => 'Sirv for PHP GD2',
            'class' => 'MagicToolbox\Sirv\Model\Image\Adapter\Gd2'
        ],
        'SIRV-IMAGEMAGICK' => [
            'title' => 'Sirv for ImageMagick',
            'class' => 'MagicToolbox\Sirv\Model\Image\Adapter\ImageMagick'
        ],
    ];

    /**
     * Is Sirv enabled flag
     *
     * @var bool
     */
    protected $isSirvEnabled = false;

    /**
     * Use Sirv image processing flag
     *
     * @var bool
     */
    protected $useSirvImageProcessing = false;

    /**
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Magento\Framework\Image\Adapter\ConfigInterface $config
     * @param \MagicToolbox\Sirv\Helper\Data $helper
     * @param array $adapterMap
     */
    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\Image\Adapter\ConfigInterface $config,
        \MagicToolbox\Sirv\Helper\Data $helper,
        array $adapterMap = []
    ) {
        parent::__construct($objectManager, $config, $adapterMap);
        $this->isSirvEnabled = $helper->isSirvEnabled();
        $this->useSirvImageProcessing = $helper->useSirvImageProcessing();
        if ($this->isSirvEnabled) {
            $this->adapterMap = array_merge($this->adapterMap, $this->sirvAdapterMap);
        }
    }

    /**
     * Return specified image adapter
     *
     * @param string $adapterAlias
     * @return \Magento\Framework\Image\Adapter\AdapterInterface
     * @throws \InvalidArgumentException
     */
    public function create($adapterAlias = null)
    {
        $adapterAlias = !empty($adapterAlias) ? $adapterAlias : $this->config->getAdapterAlias();
        if (empty($adapterAlias)) {
            throw new \InvalidArgumentException('Image adapter is not selected.');
        }

        if ($this->isSirvEnabled) {
            if ($this->useSirvImageProcessing) {
                $adapterAlias = 'SIRV';
            } elseif (in_array($adapterAlias, ['GD2', 'IMAGEMAGICK'])) {
                $adapterAlias = 'SIRV-' . $adapterAlias;
            }
        }
        return parent::create($adapterAlias);
    }
}
