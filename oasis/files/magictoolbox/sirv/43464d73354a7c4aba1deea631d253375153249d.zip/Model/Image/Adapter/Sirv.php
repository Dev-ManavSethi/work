<?php

namespace MagicToolbox\Sirv\Model\Image\Adapter;

class Sirv extends \Magento\Framework\Image\Adapter\AbstractAdapter
{
    /**
     * Required extensions
     *
     * @var array
     */
    protected $_requiredExtensions = ['curl'];

    /**
     * Is Sirv enabled flag
     *
     * @var bool
     */
    protected $isSirvEnabled = false;

    /**
     * Sirv adapter
     *
     * @var \MagicToolbox\Sirv\Model\Adapter\S3
     */
    protected $sirvAdapter = null;

    /**
     * Whether image was resized or not
     *
     * @var bool
     */
    protected $_resized = false;

    /**
     * Imaging options
     *
     * @var array
     */
    protected $_imaging_options = [];

    /**
     * Image quality
     *
     * @var int
     */
    protected $_quality = null;

    /**
     * Media directory absolute path
     *
     * @var string
     */
    protected $mediaDirectoryAbsolutePath = '';

    /**
     * Whether to use Magento watermark
     *
     * @var bool
     */
    protected $isWatermarkDisabled = false;

    /**
     * Constructor
     *
     * @param \Magento\Framework\Filesystem $filesystem
     * @param \Psr\Log\LoggerInterface $logger
     * @param \MagicToolbox\Sirv\Helper\Data $helper
     * @param \MagicToolbox\Sirv\Model\Adapter\S3 $sirvAdapter
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Filesystem $filesystem,
        \Psr\Log\LoggerInterface $logger,
        \MagicToolbox\Sirv\Helper\Data $helper,
        \MagicToolbox\Sirv\Model\Adapter\S3 $sirvAdapter,
        array $data = []
    ) {
        parent::__construct($filesystem, $logger, $data);
        $this->sirvAdapter = $sirvAdapter;
        $this->isSirvEnabled = $helper->getConfig('enabled') == 'true';
        $this->isWatermarkDisabled = $helper->getConfig('magento_watermark') == 'false';
        $profile = $helper->getConfig('profile');
        if (!empty($profile) && $profile != '-') {
            $this->setImagingOptions('profile', $profile);
        }
        $mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->mediaDirectoryAbsolutePath = $mediaDirectory->getAbsolutePath();
    }

    /**
     * Open image for processing
     *
     * @param string $fileName
     * @return void
     */
    public function open($fileName)
    {
        $this->_fileName = $fileName;
        $this->_reset();
        $this->getMimeType();
        $this->_getFileAttributes();
    }

    /**
     * For properties reset, e.g. mimeType caching.
     *
     * @return void
     */
    protected function _reset()
    {
        $this->_fileMimeType = null;
        $this->_fileType = null;
    }

    /**
     * Save image to specific path.
     * If some folders of path does not exist they will be created
     *
     * @param null|string $destination
     * @param null|string $newName
     * @return void
     * @throws \Exception  If destination path is not writable
     */
    public function save($destination = null, $newName = null)
    {
        //NOTE: prepare destination
        if (empty($destination)) {
            $destination = $this->_fileSrcPath;
        } else {
            if (empty($newName)) {
                $info = pathinfo($destination);
                $newName = $info['basename'];
                $destination = $info['dirname'];
            }
        }

        if (empty($newName)) {
            $newFileName = $this->_fileSrcName;
        } else {
            $newFileName = $newName;
        }
        $fileName = $destination . '/' . $newFileName;

        $fileName = str_replace($this->mediaDirectoryAbsolutePath, '', $fileName);

        //NOTE: check for file is cached because 'applyScheduledActions' function can return true when 'Optimize from originals' option is 'Yes'
        $modificationTime = filemtime($this->_fileName);
        if (!$this->sirvAdapter->fileExists($fileName, $modificationTime)) {
            $this->sirvAdapter->save($fileName, $this->_fileName);
        }

        //NOTE: set image quality value
        /*
        $quality = $this->quality();
        if ($quality !== null) {
            switch ($this->_fileType) {
                case IMAGETYPE_PNG:
                    $quality = round(($quality / 100) * 10);
                    if ($quality < 1) {
                        $quality = 1;
                    } elseif ($quality > 10) {
                        $quality = 10;
                    }
                    $quality = 10 - $quality;
                    $this->setImagingOptions('png.compression', $quality);
                    break;
                case IMAGETYPE_JPEG:
                    $this->setImagingOptions('quality', $quality);
                    break;
            }
        }
        */
    }

    /**
     * Render image and return its binary contents
     *
     * @return string
     */
    public function getImage()
    {
        //NOTE: download file and return contents
        return '';
    }

    /**
     * Change the image size
     *
     * @param null|int $width
     * @param null|int $height
     * @return void
     */
    public function resize($width = null, $height = null)
    {
        $dims = $this->_adaptResizeValues($width, $height);

        $this->setImagingOptions('canvas.width', $dims['frame']['width']);
        $this->setImagingOptions('canvas.height', $dims['frame']['height']);

        //NOTE: fill new image with required color
        $this->_fillBackgroundColor();

        $this->setImagingOptions('scale.width', $dims['dst']['width']);
        $this->setImagingOptions('scale.height', $dims['dst']['height']);

        $this->_resized = true;
    }

    /**
     * Fill image with main background color.
     *
     * @return void
     */
    private function _fillBackgroundColor()
    {
        list($r, $g, $b) = $this->_backgroundColor;
        $this->setImagingOptions('canvas.color', dechex($r).dechex($g).dechex($b));
    }

    /**
     * Rotate image on specific angle
     *
     * @param int $angle
     * @return void
     */
    public function rotate($angle)
    {
        $angle = (int)$angle;
        if ($angle <= 0) {
            return;
        }
        if ($angle > 360) {
            $angle = $angle - floor($angle / 360) * 360;
        }
        if ($angle <= 180) {
            $angle = -1 * $angle;
        } else {
            $angle = 360 - $angle;
        }
        $this->setImagingOptions('rotate', $angle);
        $this->_fillBackgroundColor();
    }

    /**
     * Crop image
     *
     * @param int $top
     * @param int $left
     * @param int $right
     * @param int $bottom
     * @return bool
     */
    public function crop($top = 0, $left = 0, $right = 0, $bottom = 0)
    {
        if ($left == 0 && $top == 0 && $right == 0 && $bottom == 0) {
            return false;
        }

        $newWidth = $this->_imageSrcWidth - $left - $right;
        $newHeight = $this->_imageSrcHeight - $top - $bottom;

        $this->setImagingOptions('crop.x', (int)$top);
        $this->setImagingOptions('crop.y', (int)$left);
        $this->setImagingOptions('crop.width', (int)$newWidth);
        $this->setImagingOptions('crop.height', (int)$newHeight);

        return true;
    }

    /**
     * Add watermark to image
     *
     * @param string $imagePath
     * @param int $positionX
     * @param int $positionY
     * @param int $opacity
     * @param bool $tile
     * @return void
     * @throws \Exception If media directory absolute path is empty
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.UnusedLocalVariable)
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function watermark($imagePath, $positionX = 0, $positionY = 0, $opacity = 30, $tile = false)
    {
        if ($this->isWatermarkDisabled) {
            return;
        }

        if (empty($this->mediaDirectoryAbsolutePath)) {
            throw new \Exception("Media directory absolute path is empty.");
        }

        if (strpos($imagePath, $this->mediaDirectoryAbsolutePath) !== 0) {
            return;
        }

        $sirvFileName = substr($imagePath, strlen($this->mediaDirectoryAbsolutePath));

        $modificationTime = filemtime($imagePath);
        if (!$this->sirvAdapter->fileExists($sirvFileName, $modificationTime)) {
            $this->sirvAdapter->save($sirvFileName, $imagePath);
        }

        //NOTE: $imagePath is a filesystem path to the watermark image
        list($watermarkSrcWidth, $watermarkSrcHeight, $watermarkFileType,) = $this->_getImageOptions($imagePath);
        $this->_getFileAttributes();

        $width = $this->getWatermarkWidth();
        if (empty($width)) {
            $width = $watermarkSrcWidth;
        }
        $height = $this->getWatermarkHeight();
        if (empty($height)) {
            $height = $watermarkSrcHeight;
        }
        $opacity = $this->getWatermarkImageOpacity();
        if (empty($opacity)) {
            $opacity = 50;
        }

        $this->setImagingOptions('watermark.image', urlencode($this->sirvAdapter->getRelUrlWithoutEncoding($sirvFileName)));
        $this->setImagingOptions('watermark.opacity', $opacity);

        if ($this->getWatermarkWidth() &&
            $this->getWatermarkHeight() &&
            $this->getWatermarkPosition() != self::POSITION_STRETCH
        ) {
            $this->setImagingOptions('watermark.scale.width', $width);
            $this->setImagingOptions('watermark.scale.height', $height);
            $this->setImagingOptions('watermark.scale.option', 'ignore');
        }

        if ($this->getWatermarkPosition() == self::POSITION_TILE) {
            $this->setImagingOptions('watermark.position', 'tile');
        } elseif ($this->getWatermarkPosition() == self::POSITION_STRETCH) {
            $this->setImagingOptions('watermark.position', 'center');
            $this->setImagingOptions('watermark.scale.width', $this->_imageSrcWidth);
            $this->setImagingOptions('watermark.scale.height', $this->_imageSrcHeight);
            $this->setImagingOptions('watermark.scale.option', 'ignore');
        } elseif ($this->getWatermarkPosition() == self::POSITION_CENTER) {
            $this->setImagingOptions('watermark.position', 'center');
        } elseif ($this->getWatermarkPosition() == self::POSITION_TOP_RIGHT) {
            $this->setImagingOptions('watermark.position', 'northeast');
        } elseif ($this->getWatermarkPosition() == self::POSITION_TOP_LEFT) {
            $this->setImagingOptions('watermark.position', 'northwest');
        } elseif ($this->getWatermarkPosition() == self::POSITION_BOTTOM_RIGHT) {
            $this->setImagingOptions('watermark.position', 'southeast');
        } elseif ($this->getWatermarkPosition() == self::POSITION_BOTTOM_LEFT) {
            $this->setImagingOptions('watermark.position', 'southwest');
        }
    }

    /**
     * Checks required dependencies
     *
     * @return void
     * @throws \Exception If some of dependencies are missing
     */
    public function checkDependencies()
    {
        foreach ($this->_requiredExtensions as $value) {
            if (!extension_loaded($value)) {
                throw new \Exception("Required PHP extension '{$value}' was not loaded.");
            }
        }
    }

    /**
     * Create Image from string
     *
     * @param string $text
     * @param string $font Path to font file
     * @return AbstractAdapter
     */
    public function createPngFromString($text, $font = '')
    {
        return $this;
    }

    /**
     * Reassign image dimensions
     *
     * @return void
     */
    public function refreshImageDimensions()
    {
        return;
    }

    /**
     * Returns rgba array of the specified pixel
     *
     * @param int $x
     * @param int $y
     * @return array
     */
    public function getColorAt($x, $y)
    {
        return [
           'red' => 255,
           'green' => 255,
           'blue' => 255,
           'alpha' => 0
        ];
    }

    private function setImagingOptions($name, $value)
    {
        $this->_imaging_options[$name] = $value;
    }

    public function getImagingOption($name)
    {
        return isset($this->_imaging_options[$name]) ? $this->_imaging_options[$name] : null;
    }

    public function getImagingOptionsQuery()
    {
        $query = [];
        foreach ($this->_imaging_options as $key => $value) {
            $query[] = "{$key}={$value}";
        }
        return empty($query) ? '' : '?'.implode('&', $query);
    }
}
