<?php
/**
 * Copyright 2019 aheadWorks. All rights reserved.
See LICENSE.txt for license details.
 */

namespace Aheadworks\Sarp2\Model\Profile\View\Edit\Payment\ConfigProvider\Composite;

use Magento\Framework\ObjectManagerInterface;
use Aheadworks\Sarp2\Model\ThirdPartyModule\Manager;

/**
 * Class ThirdPartyConfigProvider
 *
 * @package Aheadworks\Sarp2\Model\Profile\View\Edit\Payment\ConfigProvider\Composite
 */
class ThirdPartyConfigProvider
{
    /**
     * @var ObjectManagerInterface
     */
    private $objectManager;

    /**
     * @var Manager
     */
    private $thirdPartyModuleManager;

    /**
     * @param ObjectManagerInterface $objectManager
     * @param Manager $thirdPartyModuleManager
     */
    public function __construct(
        ObjectManagerInterface $objectManager,
        Manager $thirdPartyModuleManager
    ) {
        $this->objectManager = $objectManager;
        $this->thirdPartyModuleManager = $thirdPartyModuleManager;
    }

    /**
     * @inheritdoc
     */
    public function getConfigProviders()
    {
        $providers = [];
        if ($this->thirdPartyModuleManager->isBamboraApacModuleEnabled()) {
            $providers[] = $this->getBamboraConfigProvider();
        }

        return $providers;
    }

    /**
     * Get Bambora config provider
     *
     * @return \Aheadworks\BamboraApac\Model\Ui\ConfigProvider
     */
    private function getBamboraConfigProvider()
    {
        return $this->objectManager->get(\Aheadworks\BamboraApac\Model\Ui\ConfigProvider::class);
    }
}
