<?php
/**
 * Copyright 2019 aheadWorks. All rights reserved.
See LICENSE.txt for license details.
 */

namespace Aheadworks\Sarp2\Model\Profile\Exception;

/**
 * Class CouldNotConvertException
 * @package Aheadworks\Sarp2\Model\Profile\Exception
 */
class CouldNotConvertException extends \Exception
{
}
