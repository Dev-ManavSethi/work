<?php

namespace MagicToolbox\Sirv\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\DB\Ddl\Table;

/**
 * Class UpgradeSchema
 *
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * {@inheritdoc}
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $version = $context->getVersion();

        $setup->startSetup();

        if (!empty($version) && version_compare($version, '1.0.1', '<')) {
            /**
             * Create table 'sirv_cache'
             */
            $cacheTableName = $setup->getTable('sirv_cache');

            if ($setup->tableExists('sirv_cache')) {
                $setup->getConnection()->dropTable($cacheTableName);
            }

            $table = $setup->getConnection()->newTable(
                $cacheTableName
            )->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'ID'
            )->addColumn(
                'url',
                Table::TYPE_TEXT,
                255,
                ['nullable'  => false, 'default' => ''],
                'URL'
            )->addColumn(
                'modification_time',
                Table::TYPE_INTEGER,
                null,
                ['nullable'  => false, 'default' => 0],
                'Modification time'
            )->addIndex(
                $setup->getIdxName(
                    'sirv_cache',
                    ['url'],
                    \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE
                ),
                ['url'],
                ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE]
            )->setComment(
                'Sirv cache'
            );
            $setup->getConnection()->createTable($table);
        }

        $setup->endSetup();
    }
}
