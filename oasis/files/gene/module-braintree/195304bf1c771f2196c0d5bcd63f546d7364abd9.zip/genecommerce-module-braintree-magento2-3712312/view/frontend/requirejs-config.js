var config = {
    map: {
        '*': {
            braintreeCheckoutPayPalAdapter: 'Magento_Braintree/js/view/payment/adapter'
        }
    },
};
