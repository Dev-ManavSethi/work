
var config = {
    map: {
        '*': {
            synchronizeMedia: 'MagicToolbox_Sirv/js/synchronize_media'
        }
    }
};
