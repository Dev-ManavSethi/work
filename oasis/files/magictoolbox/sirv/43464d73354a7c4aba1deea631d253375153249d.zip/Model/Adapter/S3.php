<?php

namespace MagicToolbox\Sirv\Model\Adapter;

use MagicToolbox\Sirv\Model\Adapter\S3\Wrapper as SirvWrapper;

/**
 * Sirv adapter
 */
class S3
{
    /**
     * Sirv adapter wrapper object
     *
     * @var \MagicToolbox\Sirv\Model\Adapter\S3\Wrapper
     */
    private $sirv = null;

    /**
     * Authentication flag
     *
     * @var bool
     */
    private $auth = false;

    /**
     * Bucket
     *
     * @var string
     */
    private $bucket = '';

    /**
     * Base URL
     *
     * @var string
     */
    private $baseUrl = '';

    /**
     * Base direct URL
     *
     * @var string
     */
    private $baseDirectUrl = '';

    /**
     * Image folder
     *
     * @var string
     */
    private $imageFolder = '';

    /**
     * Image folder (encoded)
     *
     * @var string
     */
    private $encodedImageFolder = '';

    /**
     * Config helper
     *
     * @var \MagicToolbox\Sirv\Helper\Data
     */
    protected $configHelper = null;

    /**
     * Cache helper
     *
     * @var \MagicToolbox\Sirv\Helper\Cache
     */
    protected $cacheHelper = null;

    /**
     * Base media path
     *
     * @var string
     */
    protected $baseMediaPath = '';

    /**
     * Constructor
     *
     * @param \MagicToolbox\Sirv\Helper\Data $configHelper
     * @param \MagicToolbox\Sirv\Helper\Cache $cacheHelper
     */
    public function __construct(
        \MagicToolbox\Sirv\Helper\Data $configHelper,
        \MagicToolbox\Sirv\Helper\Cache $cacheHelper
    ) {
        $this->bucket = $configHelper->getConfig('bucket');

        $this->baseUrl = $this->baseDirectUrl = 'https://' . $this->bucket . '.sirv.com';

        $customDomain = $configHelper->getConfig('сustom_domain');
        if (is_string($customDomain)) {
            $customDomain = trim($customDomain);
            //NOTE: cut protocol
            $customDomain = preg_replace('#^(?:[a-zA-Z0-9]+:)?//#', '', $customDomain);
            //NOTE: cut path with query
            $customDomain = preg_replace('#^([^/]+)/.*$#', '$1', $customDomain);
            //NOTE: cut query without path
            $customDomain = preg_replace('#^([^\?]+)\?.*$#', '$1', $customDomain);
            if (!empty($customDomain)) {
                $this->baseUrl = 'https://' . $customDomain;
            }
        }

        $imageFolder = trim($configHelper->getConfig('image_folder'));
        if (!empty($imageFolder)) {
            $this->imageFolder = '/' . $imageFolder;
            $this->encodedImageFolder = '/' . rawurlencode($imageFolder);
        }

        //$this->configHelper = $configHelper;
        $this->cacheHelper = $cacheHelper;

        $this->baseMediaPath = $this->cacheHelper->getBaseMediaPath();

        if ($configHelper->isSirvEnabled() || $configHelper->isBackend()) {
            $this->sirv = new SirvWrapper([
                'host' => 's3.sirv.com',
                'bucket' => $this->bucket,
                'key' => $configHelper->getConfig('key'),
                'secret' => $configHelper->getConfig('secret'),
            ]);
            $this->auth = $this->sirv->checkCredentials();

            //NOTE: disable Sirv module in case of wrong credentials to avoid unnecessary requests to the server
            if (!$this->auth) {
                $configHelper->saveConfig('enabled', 'false');
            }
        }
    }

    /**
     * Check authentication flag
     *
     * @return bool
     */
    public function isAuth()
    {
        return $this->auth;
    }

    /**
     * Get bucket
     *
     * @return bool
     */
    public function getBucket()
    {
        return $this->bucket;
    }

    /**
     * Get profiles
     *
     * @return array
     */
    public function getProfiles()
    {
        if ($this->auth) {
            return $this->sirv->getProfiles();
        }
        return [];
    }

    /**
     * Clear cached files (on Sirv) and URL cache
     *
     * @return void
     */
    public function clearCache()
    {
        if (!$this->auth) {
            return;
        }

        while ($urls = $this->cacheHelper->getNextUrlsSet()) {
            try {
                $this->sirv->deleteMultipleObjects($urls);
            } catch (\Exception $e) {
                continue;
            }
        }

        //NOTE: to clear URL cache
        $this->cacheHelper->clearCache();
    }

    /**
     * Save file to Sirv
     *
     * @param string $destFileName
     * @param string $srcFileName
     * @return bool
     */
    public function save($destFileName, $srcFileName)
    {
        if (!$this->auth) {
            return false;
        }
        $destFileName = $this->getRelative($destFileName);
        try {
            $result = $this->sirv->uploadFile($this->imageFolder.$destFileName, $srcFileName, true);
        } catch (\Exception $e) {
            $result = false;
        }
        if ($result) {
            //NOTE: to cache URL
            $modificationTime = filemtime($srcFileName);
            $this->cacheHelper->updateCache($destFileName, $modificationTime);
        }
        return $result;
    }

    /**
     * Remove file from Sirv
     *
     * @param string $fileName
     * @return bool
     */
    public function remove($fileName)
    {
        if (!$this->auth) {
            return false;
        }
        $fileName = $this->getRelative($fileName);
        try {
            $result = $this->sirv->deleteObject($this->imageFolder.$fileName);
        } catch (\Exception $e) {
            $result = false;
        }
        if ($result) {
            $this->cacheHelper->updateCache($fileName, null, true);
        }
        return $result;
    }

    /**
     * Get file URL
     *
     * @param string $fileName
     * @return string
     */
    public function getUrl($fileName)
    {
        return $this->baseUrl.$this->encodedImageFolder.$this->getRelative($fileName);
    }

    /**
     * Get file direct URL
     *
     * @param string $fileName
     * @return string
     */
    public function getDirectUrl($fileName)
    {
        return $this->baseDirectUrl.$this->encodedImageFolder.$this->getRelative($fileName);
    }

    /**
     * Get file relative URL
     *
     * @param string $fileName
     * @return string
     */
    public function getRelUrl($fileName)
    {
        return $this->encodedImageFolder.$this->getRelative($fileName);
    }

    /**
     * Get file relative URL (image folder without encoding)
     *
     * @param string $fileName
     * @return string
     */
    public function getRelUrlWithoutEncoding($fileName)
    {
        return $this->imageFolder . $this->getRelative($fileName);
    }

    /**
     * Check if file exists
     *
     * @param string $fileName
     * @param null|int $modificationTime
     * @return bool
     */
    public function fileExists($fileName, $modificationTime = null)
    {
        $fileName = $this->getRelative($fileName);

        $cached = $this->cacheHelper->isCached($fileName, $modificationTime);

        if ($cached) {
            return true;
        }

        $url = $this->getDirectUrl($fileName) . '?info=' . time();

        $c = curl_init();
        curl_setopt($c, CURLOPT_URL, $url);
        curl_setopt($c, CURLOPT_HEADER, true);
        curl_setopt($c, CURLOPT_NOBODY, true);
        curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($c, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);

        curl_exec($c);

        //NOTE: return false if error
        if (curl_errno($c)) {
            curl_close($c);
            return false;
        }

        $code = curl_getinfo($c, CURLINFO_HTTP_CODE);
        //NOTE: for test to see if file size greater than zero
        //$size = curl_getinfo($c, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
        curl_close($c);

        if ($code == 200/* && $size*/) {
            $this->cacheHelper->updateCache($fileName, $modificationTime);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Get image info
     *
     * @param string $fileName
     * @return bool
     */
    public function getImageInfo($fileName)
    {
        if (!$this->auth) {
            return false;
        }
        $fileName = $this->getRelative($fileName);
        $tempFileName = tempnam(sys_get_temp_dir(), 'sirv');
        $fileInfo = null;
        try {
            $result = $this->sirv->downloadFile($this->imageFolder.$fileName, $tempFileName);
            if ($result) {
                $fileInfo = getimagesize($tempFileName);
            }
        } catch (\Exception $e) {
            $fileInfo = null;
        }

        is_file($tempFileName) && is_writable($tempFileName) && unlink($tempFileName);

        return $fileInfo;
    }

    /**
     * Get file relative path
     *
     * @param string $fileName
     * @return string
     */
    public function getRelative($fileName)
    {
        /*
        $base = str_replace('\\', '/', $this->baseMediaPath);
        $fileName = str_replace('\\', '/', $fileName);
        $fileName = str_replace($base, '', $fileName);
        /**/
        $fileName = str_replace($this->baseMediaPath, '', $fileName);
        if (strpos($fileName, '/') !== 0) {
            $fileName = '/' . $fileName;
        }
        return $fileName;
    }

    /**
     * Get base media path
     *
     * @return string
     */
    public function getBaseMediaPath()
    {
        return $this->baseMediaPath;
    }
}
