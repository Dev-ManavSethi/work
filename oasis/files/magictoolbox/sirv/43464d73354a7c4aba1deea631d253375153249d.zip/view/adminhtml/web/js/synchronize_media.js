
define([
    'jquery',
    'mage/template',
    'Magento_Ui/js/modal/modal',
    'mage/translate'
], function ($, mageTemplate) {
    'use strict';

    $.widget('sirv.synchronizeMedia', {

        options: {
            spinnerSelector: '#sirv_synchronize_media_with_ajax + .grid-loading-mask',
            syncTemplateSelector: '#synchronize-template',
            notificationContainerSelector: '[data-role="sirv-messages"]',
            ajaxUrl: null
        },
        currentAction: '',
        currentIteration: 0,
        isMediaSyncCanceled: false,
        isSyncInProgress: false,
        /* NOTE: files that do not exist in the file system */
        nonexistentFiles: [],
        /* NOTE: total items in media storage */
        totalItems: 0,
        /* NOTE: items in cache table */
        cachedItems: 0,
        /* NOTE: items uploaded while synchronization */
        uploadedItems: 0,
        notificationTemplates: {
            notice: '<div class="message">' +
                    '<span class="message-text">' +
                        '<strong><%- data.message %></strong><br />' +
                    '</span>' +
                   '</div>',
            error: '<div class="message message-error">' +
                    '<span class="message-text">' +
                        '<strong><%- data.message %></strong><br />' +
                    '</span>' +
                   '</div>'
        },

        /** @inheritdoc */
        _create: function () {
            this._ajaxSubmit('get_data', {});
            this.element.on('click', $.proxy(this._openSyncWindow, this));
        },

        /**
         * Get data successed
         */
        _getDataSuccess: function (response) {
            this.cachedItems = response.cached;
            this.totalItems = response.total;
            this._enableButton();
        },

        /**
         * Open sync modal window
         */
        _openSyncWindow: function () {

            this.isMediaSyncCanceled = false;
            this.isSyncInProgress = false;

            var widget = this;

            this._updateSynchTemplate(this.totalItems, this.cachedItems);

            //NOTE: clear previous notices
            $(this.options.notificationContainerSelector).html('');

            $(this.options.syncTemplateSelector).modal({
                autoOpen: false,
                clickableOverlay: false,
                type: 'popup',
                buttons: [{
                    text: 'Synchronize',
                    class: 'synchronize-button primary',
                    click: function() {
                        widget._startMediaSynchronization();
                    }
                }, {
                    text: 'Close',
                    class: 'close-button',
                    click: function() {
                        widget._closeSyncWindow();
                    }
                }],
                closed: function () {
                },
                modalCloseBtnHandler: function () {
                    widget._closeSyncWindow();
                },
                keyEventHandlers: {
                    /**
                     * Tab key press handler
                     */
                    tabKey: function () {
                        if (document.activeElement === this.modal[0]) {
                            this._setFocus('start');
                        }
                    },
                    /**
                     * Escape key press handler
                     */
                    escapeKey: function () {
                        if (this.options.isOpen && this.modal.find(document.activeElement).length ||
                            this.options.isOpen && this.modal[0] === document.activeElement) {
                            widget._closeSyncWindow();
                        }
                    }
                }
            }).modal('openModal');
        },

        /**
         * Update sync template
         */
        _updateSynchTemplate: function (total, completed) {
            var syncTemplate = $(this.options.syncTemplateSelector),
                progressInPercent = Math.floor(completed * 100 / total);

            syncTemplate.find('.progress-percent-text').html(progressInPercent);
            syncTemplate.find('.items-completed-text').html(completed);
            syncTemplate.find('.total-items-text').html(total);
            syncTemplate.find('.progress-bar').css('width', progressInPercent + '%');
        },

        /**
         * Start media synchronization
         */
        _startMediaSynchronization: function () {
            var syncTemplate = $(this.options.syncTemplateSelector),
                syncButton = $('.synchronize-button');

            this.nonexistentFiles = [];
            this.isSyncInProgress = true;
            this.uploadedItems = 0;

            this._disableButton();
            if (!syncButton.hasClass('disabled')) {
                syncButton.addClass('disabled');
                syncButton.attr('disabled', true);
            }

            //NOTE: clear previous notices
            $(this.options.notificationContainerSelector).html('');

            syncTemplate.find('.progress-bar').addClass('stripes');

            this._ajaxSynchronizeMedia();
        },

        /**
         * Synchronize media via AJAX
         */
        _ajaxSynchronizeMedia: function () {
            var maxNumberOfImages = this.totalItems - this.cachedItems;
            this._ajaxSubmit('synchronize', {
                'maxNumberOfImages': maxNumberOfImages
            });
            /*
            this.currentIteration++;
            this._ajaxSubmit('synchronize', {
                'totalItems': this.totalItems,
                'currentPage': this.currentIteration
            });
            */
        },

        /**
         * Synchronize success
         */
        _synchronizeSuccess: function (response) {

            this.uploadedItems += response.uploaded;
            this.cachedItems += response.cached;

            if (response.nonexistentFiles.length) {
                this.nonexistentFiles = response.nonexistentFiles;
            }

            this._updateSynchTemplate(this.totalItems, this.cachedItems);

            if (this.isMediaSyncCanceled) {
                return;
            }

            if (response.completed || (this.cachedItems >= this.totalItems)) {
                this._completeSynchronization();
            } else {
                this._ajaxSynchronizeMedia();
            }
        },

        /**
         * Media synchronization is successful
         */
        _completeSynchronization: function () {

            var syncTemplate = $(this.options.syncTemplateSelector),
                syncButton = $('.synchronize-button');

            if (syncButton.hasClass('disabled')) {
                syncButton.removeClass('disabled');
                syncButton.attr('disabled', false);
            }

            syncTemplate.find('.progress-bar').removeClass('stripes');

            this.isSyncInProgress = false;

            var message = 'Media gallery images have been synced. ';
            if (this.uploadedItems == 0) {
                message += 'No files have'
            } else if (this.uploadedItems == 1) {
                message += '1 file has';
            } else {
                message += this.uploadedItems + ' files have';
            }
            message += ' been uploaded (' + this.totalItems + ' images total).';

            this._displayNotification(message, false);

            if (this.nonexistentFiles.length) {
                message = 'Some files were not uploaded because they do not exist in the file system!';
                this._displayNotification(message, true);
                this._displayNotification("Files (" + this.nonexistentFiles.length + "):\n'" + this.nonexistentFiles.join("',\n'") + "'", true);
            }

            this._enableButton();
        },

        /**
         * Ajax submit
         */
        _ajaxSubmit: function (action, params) {

            this._disableButton();

            this.currentAction = action;

            //NOTE: to show spinner
            $(this.options.spinnerSelector).css('visibility', 'visible');

            var data = {
                isAjax: true,
                dataAction: action
            };
            data = $.extend(data, params);

            $.ajax({
                url: this.options.ajaxUrl,
                data: data,
                type: 'post',
                dataType: 'json',
                context: this,
                /*crossDomain: true,*/
                success: this._ajaxSuccess,
                error: this._ajaxError

            });
        },

        /**
         * Ajax success
         */
        _ajaxSuccess: function (response, textStatus, jqXHR) {
            if ($.type(response) === 'object' && !$.isEmptyObject(response)) {
                if (response['error']) {
                    this._displayNotification(response['error']);
                    this.isSyncInProgress = false;
                } else {
                    if (this.currentAction) {
                        var parts = this.currentAction.split('_');
                        for (var i = 1; i < parts.length; i++) {
                            if (parts[i].length) {
                                parts[i] = parts[i].charAt(0).toUpperCase() + parts[i].slice(1);
                            }
                        }
                        var methodName = '_' + parts.join('') + 'Success';
                        if (typeof(this[methodName]) == 'function') {
                            this[methodName](response);
                        }
                    }
                }
            }

            //NOTE: to hide spinner
            $(this.options.spinnerSelector).css('visibility', 'hidden');
        },

        /**
         * Ajax error
         */
        _ajaxError: function (jqXHR, textStatus, errorThrown) {
            if ('parsererror' == textStatus) {
                if (window.console) {
                    console.error(errorThrown);
                }
            }
            if ('error' == textStatus) {
                this._displayNotification(errorThrown, true);
            }
        },

        /**
         * Close sync modal window
         */
        _closeSyncWindow: function (confirm) {
            if (typeof(confirm) == 'undefined') {
                confirm = false;
            }
            confirm = confirm || this.isSyncInProgress;
            var message = $.mage.__('Are you sure you want to interrupt synchronization!?');

            if (!confirm || window.confirm(message)) {
                this.isMediaSyncCanceled = true;
                $(this.options.syncTemplateSelector).modal('closeModal');
            }
        },

        /**
         * Enable button
         */
        _enableButton: function () {
            if (this.element.hasClass('disabled')) {
                this.element.removeClass('disabled');
                this.element.attr('disabled', false);
            }
        },

        /**
         * Disable button
         */
        _disableButton: function () {
            if (!this.element.hasClass('disabled')) {
                this.element.addClass('disabled');
                this.element.attr('disabled', true);
            }
        },

        /**
         * Display notification
         */
        _displayNotification: function (message, error) {
            if (typeof(error) == 'undefined') {
                error = true;
            }
            var template = error ? this.notificationTemplates.error : this.notificationTemplates.notice,
                message = mageTemplate(template, {
                    data: {
                        message: $.mage.__(message),
                    }
                });
            $(this.options.notificationContainerSelector).append(message);
        }

    });

    return $.sirv.synchronizeMedia;
});
