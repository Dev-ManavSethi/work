<?php

namespace Justuno\Social\Block\Frontend;

use Magento\Framework\View\Element\Template;
use Justuno\Social\Helper\Data;


class Embed extends Template
{
    /**
     * @var Data
     */
    private $helper;
    

    /**
     * Embed constructor.
     * @param Data $helper
     * @param Template\Context $context
     */
    public function __construct(
        Data $helper,
        Template\Context $context)
    {
        $this->helper = $helper;
        parent::__construct($context);
    }
	
    /**
     * @return string
     */
    public function getValueACCID()
    {
        return $this->helper->getACCID();
	}

	/**
     * @return string
     */
    public function getValueJUAJAX()
    {
        return $this->helper->getJUAJAX();
	}
}