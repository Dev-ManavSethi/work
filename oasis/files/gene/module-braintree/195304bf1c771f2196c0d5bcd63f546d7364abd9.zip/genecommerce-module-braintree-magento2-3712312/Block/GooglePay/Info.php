<?php

namespace Magento\Braintree\Block\GooglePay;

/**
 * Class Info
 * @package Magento\Braintree\Model\GooglePay
 * @author Aidan Threadgold <aidan@gene.co.uk>
 */
class Info extends \Magento\Braintree\Block\Info
{
}
