<?php

namespace MagicToolbox\Sirv\Block\Adminhtml\Settings;

class Edit extends \Magento\Backend\Block\Widget\Form\Container
{
    /**
     * Class constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_objectId = 'object_id';
        $this->_controller = 'adminhtml_settings';
        $this->_blockGroup = 'MagicToolbox_Sirv';

        parent::_construct();

        $this->removeButton('back');
        $this->removeButton('reset');

        $class = 'sirv-settings-button';

        $this->addButton(
            'sirv_flush_image_cache',
            [
                'class' => $class,
                'label' => __('Flush Image Cache'),
                'onclick' => 'setLocation(\'' . $this->getUrl('*/*/flush') . '\')',
            ],
            0,
            1
        );

        $this->addButton(
            'sirv_synchronize_media_with_ajax',
            [
                'class' => $class,
                'label' => __('Sync Media Gallery'),
                'onclick' => 'return false',
                'disabled' => 'disabled',
                'data_attribute' => ['mage-init' => '{"synchronizeMedia": {"ajaxUrl": "'.$this->escapeUrl($this->getUrl('sirv/ajax/synchronize')).'"}}'],
                'after_html' => '<div data-role="spinner" class="grid-loading-mask">'.
                                    '<div class="spinner">'.
                                        '<span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span>'.
                                    '</div>'.
                                '</div>',
            ],
            0,
            2
        );

        $this->updateButton('save', 'label', __('Save Settings'));
        $this->updateButton('save', 'class', 'save primary ' . $class);
    }
}
