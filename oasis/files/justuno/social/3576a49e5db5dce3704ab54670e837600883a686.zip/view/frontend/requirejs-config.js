// eslint-disable-next-line no-unused-vars
var config = {
	'map': {
		'*': {
			'embed': 'Justuno_Social/js/embed',
			'magexsync': 'Justuno_Social/js/magexsync'
		}
	}
};