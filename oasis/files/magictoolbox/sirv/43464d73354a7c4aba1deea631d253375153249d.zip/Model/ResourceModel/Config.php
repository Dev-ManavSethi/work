<?php

namespace MagicToolbox\Sirv\Model\ResourceModel;

/**
 * Config resource model
 */
class Config extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('sirv_config', 'id');
    }
}
