<?php
/**
 * Copyright 2019 aheadWorks. All rights reserved.
See LICENSE.txt for license details.
 */

namespace Aheadworks\Sarp2\Model\Product\Subscription\Option\Source;

use Aheadworks\Sarp2\Api\SubscriptionOptionRepositoryInterface;
use Aheadworks\Sarp2\Model\Plan\Checker as PlanChecker;
use Aheadworks\Sarp2\Model\Product\Checker\IsSubscription;

/**
 * Class Frontend
 * @package Aheadworks\Sarp2\Model\Product\Subscription\Option\Source
 */
class Frontend
{
    /**
     * @var IsSubscription
     */
    private $isSubscriptionChecker;

    /**
     * @var SubscriptionOptionRepositoryInterface
     */
    private $optionRepository;

    /**
     * @var PlanChecker
     */
    private $planChecker;

    /**
     * @param IsSubscription $isSubscriptionChecker
     * @param SubscriptionOptionRepositoryInterface $optionRepository
     * @param PlanChecker $planChecker
     */
    public function __construct(
        IsSubscription $isSubscriptionChecker,
        SubscriptionOptionRepositoryInterface $optionRepository,
        PlanChecker $planChecker
    ) {
        $this->isSubscriptionChecker = $isSubscriptionChecker;
        $this->optionRepository = $optionRepository;
        $this->planChecker = $planChecker;
    }

    /**
     * Get frontend options
     *
     * @param int $productId
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getOptionArray($productId)
    {
        $optionArray = [];
        if (!$this->isSubscriptionChecker->checkById($productId, true)) {
            $optionArray[0] = __('One-off purchase (No subscription)');
        }

        $options = $this->optionRepository->getList($productId);
        foreach ($options as $option) {
            if ($this->planChecker->isEnabled($option->getPlanId())) {
                $optionArray[$option->getOptionId()] = $option->getFrontendTitle();
            }
        }

        return $optionArray;
    }

    /**
     * Get frontend options for plan selection
     *
     * @param int $productId
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getPlanOptionArray($productId)
    {
        $optionArray = [];
        $options = $this->optionRepository->getList($productId);
        foreach ($options as $option) {
            if ($this->planChecker->isEnabled($option->getPlanId())) {
                $optionArray[$option->getPlanId()] = $option->getFrontendTitle();
            }
        }

        return $optionArray;
    }
}
