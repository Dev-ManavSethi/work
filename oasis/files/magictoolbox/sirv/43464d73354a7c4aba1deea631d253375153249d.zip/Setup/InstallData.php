<?php

namespace MagicToolbox\Sirv\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

/**
 * @codeCoverageIgnore
 */
class InstallData implements InstallDataInterface
{
    /**
     * Module configuration file reader
     *
     * @var \Magento\Framework\Module\Dir\Reader
     */
    protected $modulesConfFileReader;

    /**
     * @param \Magento\Framework\Module\Dir\Reader $modulesReader
     */
    public function __construct(
        \Magento\Framework\Module\Dir\Reader $modulesReader
    ) {
        $this->modulesConfFileReader = $modulesReader;
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        /**
         * Install default config
         */
        $data = [];
        $moduleEtcPath = $this->modulesConfFileReader->getModuleDir(\Magento\Framework\Module\Dir::MODULE_ETC_DIR, 'MagicToolbox_Sirv');
        $fileName = $moduleEtcPath.'/settings.xml';
        $useErrors = libxml_use_internal_errors(true);
        $xml = simplexml_load_file($fileName);
        libxml_use_internal_errors($useErrors);
        if ($xml) {
            $fields = $xml->xpath('/settings/group/fields/field');
            foreach ($fields as $field) {
                $data[] = [
                    'name' => (string)$field->name,
                    'value' => (string)$field->value
                ];
            }
            unset($xml);
        }
        if ($setup->tableExists('sirv_config')) {
            //NOTE: clear just in case
            $configTableName = $setup->getTable('sirv_config');
            $setup->getConnection()->truncateTable($configTableName);

            $setup->getConnection()->insertMultiple($configTableName, $data);
        }

        $setup->endSetup();
    }
}
