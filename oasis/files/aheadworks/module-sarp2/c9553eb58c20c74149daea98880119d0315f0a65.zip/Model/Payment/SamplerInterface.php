<?php
/**
 * Copyright 2019 aheadWorks. All rights reserved.
See LICENSE.txt for license details.
 */

namespace Aheadworks\Sarp2\Model\Payment;

/**
 * Interface SamplerInterface
 * @package Aheadworks\Sarp2\Model\Payment
 */
interface SamplerInterface
{
    /**
     * Place payment method
     *
     * @param SamplerInfoInterface $info
     * @return $this
     */
    public function place(SamplerInfoInterface $info);

    /**
     * Revert payment method
     *
     * @param SamplerInfoInterface $info
     * @return $this
     */
    public function revert(SamplerInfoInterface $info);
}
