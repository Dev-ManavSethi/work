<?php

namespace MagicToolbox\Sirv\Model\ResourceModel\Cache;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('MagicToolbox\Sirv\Model\Cache', 'MagicToolbox\Sirv\Model\ResourceModel\Cache');
    }

    /**
     * Truncate the cache table
     *
     * @return void
     */
    public function truncate()
    {
        $this->getConnection()->truncateTable($this->getMainTable());
    }
}
