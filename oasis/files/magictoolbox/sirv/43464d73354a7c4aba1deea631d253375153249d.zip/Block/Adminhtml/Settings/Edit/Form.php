<?php

namespace MagicToolbox\Sirv\Block\Adminhtml\Settings\Edit;

/**
 * Adminhtml settings edit form
 *
 */
class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    /**
     * Module configuration file reader
     *
     * @var \Magento\Framework\Module\Dir\Reader
     */
    protected $modulesConfFileReader;

    /**
     * Model factory
     *
     * @var \MagicToolbox\Sirv\Model\ConfigFactory
     */
    protected $sirvConfigFactory = null;

    /**
     * Sirv adapter factory
     *
     * @var \MagicToolbox\Sirv\Model\Adapter\S3Factory
     */
    protected $s3Factory = null;

    /**
     * @var \Magento\Framework\Component\ComponentRegistrar
     */
    protected $componentRegistrar;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Framework\Module\Dir\Reader $modulesReader
     * @param \MagicToolbox\Sirv\Model\ConfigFactory $configFactory
     * @param \MagicToolbox\Sirv\Model\Adapter\S3Factory $s3Factory
     * @param \Magento\Framework\Component\ComponentRegistrar $componentRegistrar
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Framework\Module\Dir\Reader $modulesReader,
        \MagicToolbox\Sirv\Model\ConfigFactory $configFactory,
        \MagicToolbox\Sirv\Model\Adapter\S3Factory $s3Factory,
        \Magento\Framework\Component\ComponentRegistrar $componentRegistrar,
        array $data = []
    ) {
        $this->modulesConfFileReader = $modulesReader;
        $this->sirvConfigFactory = $configFactory;
        $this->s3Factory = $s3Factory;
        $this->componentRegistrar = $componentRegistrar;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post', 'class' => 'magictoolbox-config']]
        );

        $form->setUseContainer(true);//NOTE: to display form tag

        $moduleEtcPath = $this->modulesConfFileReader->getModuleDir(\Magento\Framework\Module\Dir::MODULE_ETC_DIR, 'MagicToolbox_Sirv');
        $useErrors = libxml_use_internal_errors(true);
        $xml = simplexml_load_file($moduleEtcPath . '/settings.xml');
        libxml_use_internal_errors($useErrors);

        if ($xml) {
            if (isset($xml->notice)) {
                $fieldset = $form->addFieldset('sirv_group_fieldset_notice', ['legend' => '']);
                $fieldset->addField('mt-config-notice', 'label', [
                    'label' => null,
                    'after_element_html' => (string)$xml->notice
                ]);
            }

            $moduleDir = $this->componentRegistrar->getPath(
                \Magento\Framework\Component\ComponentRegistrar::MODULE,
                'MagicToolbox_Sirv'
            );
            $moduleInfo = json_decode(file_get_contents($moduleDir . '/composer.json'));

            if (is_object($moduleInfo) && isset($moduleInfo->version)) {
                $versionString = 'Version: ' . $moduleInfo->version;

                $hostname = 'www.magictoolbox.com';
                $errno = 0;
                $errstr = '';
                $path = 'api/platform/sirvmagento2/version/?t=' . time();
                $level = error_reporting(0);
                $handle = fsockopen('ssl://' . $hostname, 443, $errno, $errstr, 30);
                error_reporting($level);
                if ($handle) {
                    $response = '';
                    $headers  = "GET /{$path} HTTP/1.1\r\n";
                    $headers .= "Host: {$hostname}\r\n";
                    $headers .= "Connection: Close\r\n\r\n";
                    fwrite($handle, $headers);
                    while (!feof($handle)) {
                        $response .= fgets($handle);
                    }
                    fclose($handle);
                    $response = substr($response, strpos($response, "\r\n\r\n") + 4);
                    $responseObj = json_decode($response);
                    if (is_object($responseObj) && isset($responseObj->version)) {
                        $match = [];
                        if (preg_match('#v([0-9]++(?:\.[0-9]++)*+)#is', $responseObj->version, $match)) {
                            if (version_compare($moduleInfo->version, $match[1], '<')) {
                                $versionString .= '&nbsp;&nbsp;&nbsp;&nbsp;Latest version: '.$match[1].' (<a href="https://sirv.com/integration/magento/" target="_blank" style="margin: 0;">download zip</a>)';
                            }
                        }
                    }
                }

                $fieldset = $form->addFieldset('sirv_group_fieldset_version', ['legend' => '']);
                $fieldset->addField('mt-config-version', 'label', [
                    'label' => null,
                    'after_element_html' => $versionString
                ]);
            }

            $config = [];
            $data = $this->sirvConfigFactory->create()->getCollection()->getData();
            foreach ($data as $row) {
                $config[$row['name']] = $row['value'];
            }

            foreach ($xml->group as $group) {
                $fieldset = $form->addFieldset('sirv_group_fieldset_' . (string)$group['id'], ['legend' => __((string)$group->label)]);

                if (isset($group->notice)) {
                    $field = $fieldset->addField('mt-' . (string)$group['id'] . '-notice', 'label', [
                        'label' => null,
                        'after_element_html' => (string)$group->notice,
                    ]);
                }

                foreach ($group->fields->field as $field) {
                    $type = (string)$field->type;
                    $name = (string)$field->name;

                    $required = isset($field->required) ? (string)$field->required : '';
                    $required = $required == 'true' ? true : false;

                    $fieldConfig = [
                        'label'     => (string)$field->label,
                        'title'     => (string)$field->label,
                        'name'      => 'magictoolbox[' . $name . ']',
                        'note'      => (string)$field->notice,
                        'value'     => isset($config[$name]) ? $config[$name] : (string)$field->value,
                        'class'     => 'mt-option',
                        'required'  => $required,
                    ];

                    if ($type == 'select') {
                        $fieldConfig['values'] = [];
                        foreach ($field->options->option as $option) {
                            $fieldConfig['values'][] = ['value' => (string)$option->value, 'label' => (string)$option->label];
                        }
                        if ($name == 'profile') {
                            $sirvAdapter = $this->s3Factory->create();
                            if ($sirvAdapter->isAuth()) {
                                $profiles = $sirvAdapter->getProfiles();
                                foreach ($profiles as $profile) {
                                    $fieldConfig['values'][] = ['value' => $profile, 'label' => $profile];
                                }
                                if (!in_array($fieldConfig['value'], $profiles)) {
                                    $fieldConfig['value'] = '-';
                                }
                            }
                        }
                    }
                    $field = $fieldset->addField('mt-' . $name, $type, $fieldConfig);
                }
            }
            unset($xml);
        }

        $this->setForm($form);

        return parent::_prepareForm();
    }
}
