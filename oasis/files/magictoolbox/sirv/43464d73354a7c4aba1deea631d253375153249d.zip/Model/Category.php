<?php

namespace MagicToolbox\Sirv\Model;

/**
 * Catalog category
 *
 */
class Category extends \Magento\Catalog\Model\Category
{
    /**
     * Is Sirv enabled flag
     *
     * @var bool
     */
    protected $isSirvEnabled = false;

    /**
     * Sirv adapter
     *
     * @var \MagicToolbox\Sirv\Model\Adapter\S3
     */
    protected $sirvAdapter = null;

    /**
     * Media directory absolute path
     *
     * @var string
     */
    protected $mediaDirectoryAbsolutePath = '';

    /**
     * Model construct for object initialization
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        $helper = $objectManager->get(\MagicToolbox\Sirv\Helper\Data::class);
        $this->isSirvEnabled = $helper->isSirvEnabled();

        if ($this->isSirvEnabled) {
            $this->sirvAdapter = $objectManager->get(\MagicToolbox\Sirv\Model\Adapter\S3::class);

            $filesystem = $objectManager->get(\Magento\Framework\Filesystem::class);
            $mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
            $this->mediaDirectoryAbsolutePath = $mediaDirectory->getAbsolutePath();
        }
    }

    /**
     * Get category image url
     *
     * @param string $attributeCode
     * @return bool|string
     */
    public function getImageUrl($attributeCode = 'image')
    {
        if ($this->isSirvEnabled) {
            $image = $this->getData($attributeCode);
            if ($image && is_string($image)) {
                $relPath = 'catalog/category/' . $image;
                $fullPath = $this->mediaDirectoryAbsolutePath . $relPath;
                if (file_exists($fullPath)) {
                    $modificationTime = filemtime($fullPath);
                    if (!$this->sirvAdapter->fileExists($relPath, $modificationTime)) {
                        $this->sirvAdapter->save($relPath, $fullPath);
                    }
                    return $this->sirvAdapter->getUrl($relPath);
                }
            }
        }

        return parent::getImageUrl($attributeCode);
    }
}
