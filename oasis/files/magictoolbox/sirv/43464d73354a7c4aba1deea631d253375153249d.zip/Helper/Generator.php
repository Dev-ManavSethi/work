<?php

namespace MagicToolbox\Sirv\Helper;

/**
 * Generator class helps in generating other classes during compilation.
 *
 */
class Generator
{
    /**
     * Constructor
     *
     * @param \MagicToolbox\Sirv\Model\View\Asset\ImageFactory $assetImageFactory
     */
    public function __construct(
        \MagicToolbox\Sirv\Model\View\Asset\ImageFactory $assetImageFactory
    ) {
        //NOTE: during compilation the Magento compiler will create all the necessary files in the 'generated' folder
    }
}
