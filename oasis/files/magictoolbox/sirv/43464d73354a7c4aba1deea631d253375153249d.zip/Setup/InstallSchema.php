<?php

namespace MagicToolbox\Sirv\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\DB\Ddl\Table;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        /**
         * Create table 'sirv_config'
         */
        if (!$setup->tableExists('sirv_config')) {
            $table = $setup->getConnection()->newTable(
                $setup->getTable('sirv_config')
            )->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'ID'
            )->addColumn(
                'name',
                Table::TYPE_TEXT,
                64,
                ['nullable'  => false],
                'Name'
            )->addColumn(
                'value',
                Table::TYPE_TEXT,
                null,
                ['nullable'  => false],
                'Value'
            )->addIndex(
                $setup->getIdxName(
                    'sirv_cache',
                    ['name'],
                    \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE
                ),
                ['name'],
                ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE]
            )->setComment(
                'Sirv configuration'
            );
            $setup->getConnection()->createTable($table);
        }

        /**
         * Create table 'sirv_cache'
         */
        $cacheTableName = $setup->getTable('sirv_cache');
        $doCreateCacheTable = false;
        if ($setup->tableExists('sirv_cache')) {
            $doCreateCacheTable = $setup->getConnection()->tableColumnExists($cacheTableName, 'last_checked');
            if ($doCreateCacheTable) {
                $setup->getConnection()->dropTable($cacheTableName);
            }
        } else {
            $doCreateCacheTable = true;
        }

        if ($doCreateCacheTable) {
            $table = $setup->getConnection()->newTable(
                $cacheTableName
            )->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'ID'
            )->addColumn(
                'url',
                Table::TYPE_TEXT,
                255,
                ['nullable'  => false, 'default' => ''],
                'URL'
            )->addColumn(
                'modification_time',
                Table::TYPE_INTEGER,
                null,
                ['nullable'  => false, 'default' => 0],
                'Modification time'
            )->addIndex(
                $setup->getIdxName(
                    'sirv_cache',
                    ['url'],
                    \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE
                ),
                ['url'],
                ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE]
            )->setComment(
                'Sirv cache'
            );
            $setup->getConnection()->createTable($table);
        }

        $setup->endSetup();
    }
}
