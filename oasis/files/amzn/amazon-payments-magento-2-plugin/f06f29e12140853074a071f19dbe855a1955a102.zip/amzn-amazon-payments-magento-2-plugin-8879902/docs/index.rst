.. image:: /images/amazon_payments_logo.png
   :align: right

===========================================================================
Amazon Pay and Login with Amazon extension for Magento 2
===========================================================================

.. toctree::
   :maxdepth: 3

   overview
   prerequisites
   installation
   configuration
   login
   flow
   customisation
   testing
   troubleshooting
   faq