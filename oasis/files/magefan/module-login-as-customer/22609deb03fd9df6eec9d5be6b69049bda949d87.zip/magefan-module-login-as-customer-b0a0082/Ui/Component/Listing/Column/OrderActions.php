<?php
/**
 * Copyright © Magefan (support@magefan.com). All rights reserved.
 * Please visit Magefan.com for license details (https://magefan.com/end-user-license-agreement).
 *
 * Glory to Ukraine! Glory to the heroes!
 */

namespace Magefan\LoginAsCustomer\Ui\Component\Listing\Column;

class OrderActions extends AbstractColumn
{

    protected $sourceColumnName = 'customer_id';
}
