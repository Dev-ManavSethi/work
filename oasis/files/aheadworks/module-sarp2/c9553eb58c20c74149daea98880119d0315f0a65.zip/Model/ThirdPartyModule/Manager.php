<?php
/**
 * Copyright 2019 aheadWorks. All rights reserved.
See LICENSE.txt for license details.
 */

namespace Aheadworks\Sarp2\Model\ThirdPartyModule;

use Magento\Framework\Module\ModuleListInterface;

/**
 * Class Manager
 *
 * @package Aheadworks\Sarp2\Model\ThirdPartyModule
 */
class Manager
{
    /**
     * Aheadworks BamboraApac module name
     */
    const BAMBORA_MODULE_NAME = 'Aheadworks_BamboraApac';

    /**
     * @var ModuleListInterface
     */
    private $moduleList;

    /**
     * @param ModuleListInterface $moduleList
     */
    public function __construct(
        ModuleListInterface $moduleList
    ) {
        $this->moduleList = $moduleList;
    }

    /**
     * Check if Aheadworks BamboraApac module enabled
     *
     * @return bool
     */
    public function isBamboraApacModuleEnabled()
    {
        return $this->moduleList->has(self::BAMBORA_MODULE_NAME);
    }
}
