<?php
/**
 * Copyright 2019 aheadWorks. All rights reserved.
See LICENSE.txt for license details.
 */


return [
    [1, 0, 'Plan with initial fee and trial period'],
    [2, 0, 'Plan with initial fee and without trial period'],
    [3, 0, 'Plan without initial fee and trial period'],
    [4, 0, 'Daily plan'],
    [5, 0, 'Weekly plan'],
    [6, 0, 'Monthly plan']
];
