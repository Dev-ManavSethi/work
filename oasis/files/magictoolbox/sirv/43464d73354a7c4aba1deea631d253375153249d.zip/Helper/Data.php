<?php

namespace MagicToolbox\Sirv\Helper;

/**
 * Data helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * Backend flag
     *
     * @var bool
     */
    protected $isBackend = false;

    /**
     * Config model factory
     *
     * @var \MagicToolbox\Sirv\Model\ConfigFactory
     */
    protected $configModelFactory = null;

    /**
     * Config
     *
     * @var array
     */
    protected $sirvConfig = null;

    /**
     * Is Sirv enabled flag
     *
     * @var bool
     */
    protected $isSirvEnabled = false;

    /**
     * Use Sirv image processing flag
     *
     * @var bool
     */
    protected $useSirvImageProcessing = true;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\App\State $appState
     * @param \MagicToolbox\Sirv\Model\ConfigFactory $configModelFactory
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\State $appState,
        \MagicToolbox\Sirv\Model\ConfigFactory $configModelFactory
    ) {
        parent::__construct($context);
        $this->isBackend = ($appState->getAreaCode() == \Magento\Framework\App\Area::AREA_ADMINHTML);
        $this->configModelFactory = $configModelFactory;
        $this->loadConfig();
    }

    public function getConfigModel()
    {
        return $this->configModelFactory->create();
    }

    public function loadConfig()
    {
        $this->sirvConfig = [];
        $collection = $this->getConfigModel()->getCollection();
        foreach ($collection->getData() as $data) {
            $this->sirvConfig[$data['name']] = $data['value'];
        }
        $this->isSirvEnabled = isset($this->sirvConfig['enabled']) ? $this->sirvConfig['enabled'] == 'true' : false;
        //$this->useSirvImageProcessing = isset($this->sirvConfig['sirv_image_processing']) ? $this->sirvConfig['sirv_image_processing'] == 'true' : false;
    }

    public function getConfig($name = null)
    {
        return $name ? (isset($this->sirvConfig[$name]) ? $this->sirvConfig[$name] : null) : $this->sirvConfig;
    }

    public function saveConfig($name, $value)
    {
        $model = $this->getConfigModel();
        $model->load($name, 'name');
        $data = $model->getData();

        if (empty($data)) {
            $model->setData('name', $name);
        }

        $model->setData('value', $value);
        $model->save();
        $this->sirvConfig[$name] = $name;
    }

    public function isBackend()
    {
        return $this->isBackend;
    }

    public function isSirvEnabled()
    {
        return $this->isSirvEnabled;
    }

    public function useSirvImageProcessing()
    {
        return $this->useSirvImageProcessing;
    }
}
