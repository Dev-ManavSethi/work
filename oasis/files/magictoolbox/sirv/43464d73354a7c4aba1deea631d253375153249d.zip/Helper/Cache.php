<?php

namespace MagicToolbox\Sirv\Helper;

/**
 * Cache helper
 */
class Cache extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * Cache model
     *
     * @var \MagicToolbox\Sirv\Model\Cache
     */
    protected $sirvCache = null;

    /**
     * Base media path
     *
     * @var string
     */
    protected $baseMediaPath = '';

    /**
     * Is Sirv enabled flag
     *
     * @var bool
     */
    protected $isSirvEnabled = false;

    /**
     * Image folder
     *
     * @var string
     */
    private $imageFolder = '';

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Catalog\Model\Product\Media\Config $catalogProductMediaConfig
     * @param \MagicToolbox\Sirv\Helper\Data $helper
     * @param \MagicToolbox\Sirv\Model\CacheFactory $cacheFactory
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Catalog\Model\Product\Media\Config $catalogProductMediaConfig,
        \MagicToolbox\Sirv\Helper\Data $helper,
        \MagicToolbox\Sirv\Model\CacheFactory $cacheFactory
    ) {
        $this->sirvCache = $cacheFactory->create();

        //NOTE: catalog/product
        $this->baseMediaPath = $catalogProductMediaConfig->getBaseMediaPath();

        $this->isSirvEnabled = $helper->isSirvEnabled();

        $imageFolder = trim($helper->getConfig('image_folder'));
        if (!empty($imageFolder)) {
            $this->imageFolder = '/' . $imageFolder;
        }

        parent::__construct($context);
    }

    /**
     * Check if URL is cached
     *
     */
    public function isCached($url, $modificationTime = null)
    {
        try {
            $this->sirvCache->clearInstance();
            $model = $this->sirvCache->load($url, 'url');
            $timestamp = $model->getModificationTime();
            if (!$timestamp) {
                //NOTE: URL is not in cache
                return false;
            }
            if ($modificationTime === null) {
                return true;
            }
            $timestamp = (int)$timestamp;
        } catch (\Exception $e) {
            return false;
        }
        return $modificationTime <= $timestamp;
    }

    /**
     * Update Cache
     *
     */
    public function updateCache($url, $modificationTime, $remove = false)
    {
        try {
            $this->sirvCache->clearInstance();
            $model = $this->sirvCache->load($url, 'url');
            if ($remove) {
                $model->delete();
            } else {
                $model->setUrl($url);
                $model->setModificationTime($modificationTime);
                $model->save();
            }
        } catch (\Exception $e) {
            throw new \Exception('Could not access caching database table.');
            return false;
        }
        return true;
    }

    /**
     * Flush Cache
     *
     */
    public function clearCache()
    {
        $this->sirvCache->getCollection()->truncate();
    }

    public function getCacheCollection()
    {
        return $this->sirvCache->getCollection();
    }

    public function getCacheTable()
    {
        return $this->sirvCache->getResource()->getMainTable();
    }

    public function getBaseMediaPath()
    {
        return $this->baseMediaPath;
    }

    public function getNextUrlsSet($length = 100)
    {

        static $urls = null, $offset = 0;

        if ($urls == null) {
            $urls = [];
            $collection = $this->sirvCache->getCollection();
            $collectionSize = $collection->getSize();
            if ($collectionSize) {
                foreach ($collection->getIterator() as $record) {
                    $urls[] = $this->imageFolder . $record->getData('url');
                }
            }
        }

        $result = array_slice($urls, $offset, $length);
        if (empty($result)) {
            $offset = 0;
        } else {
            $offset += $length;
        }

        return $result;
    }
}
