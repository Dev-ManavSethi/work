<?php

namespace MagicToolbox\Sirv\Model\ResourceModel;

/**
 * Gallery resource model
 */
class Gallery extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('catalog_product_entity_media_gallery', 'value_id');
    }
}
