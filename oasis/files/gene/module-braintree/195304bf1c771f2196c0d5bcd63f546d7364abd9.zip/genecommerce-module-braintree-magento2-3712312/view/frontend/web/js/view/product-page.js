define(
    ['uiComponent'],
    function (Component) {
        'use strict';

        return Component.extend({

        });
    }
);