var config = {
    map: {
        '*': {
            feedReport: 'Mirasvit_Feed/js/report'
        }
    }
};