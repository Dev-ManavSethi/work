<?php

namespace MagicToolbox\Sirv\Model\Product;

/**
 * Sirv link model
 *
 */
class Image extends \Magento\Catalog\Model\Product\Image
{
    /**
     * @var \MagicToolbox\Sirv\Model\View\Asset\ImageFactory
     */
    protected $mtViewAssetImageFactory = null;

    /**
     * @var \Magento\Catalog\Model\View\Asset\PlaceholderFactory
     */
    protected $mtViewAssetPlaceholderFactory = null;

    /**
     * @var \MagicToolbox\Sirv\Model\View\Asset\Image
     */
    protected $mtImageAsset = null;

    /**
     * @var \Magento\Catalog\Model\Product\Image\ParamsBuilder
     */
    protected $mtParamsBuilder = null;

    /**
     * @var \Magento\Catalog\Model\Product\Image\SizeCache
     */
    protected $mtSizeCache = null;

    /**
     * Is Sirv enabled flag
     *
     * @var bool
     */
    protected $isSirvEnabled = false;

    /**
     * Use Sirv image processing flag
     *
     * @var bool
     */
    protected $useSirvImageProcessing = false;

    /**
     * Sirv adapter
     *
     * @var \MagicToolbox\Sirv\Model\Adapter\S3
     */
    protected $sirvAdapter = null;

    /**
     * Whether 'viewAssetImageFactory' property exists
     *
     * @var bool
     */
    protected $viewAssetImageFactoryExists = false;

    /**
     * Media directory absolute path
     *
     * @var string
     */
    protected $mediaDirectoryAbsolutePath = '';

    /**
     * Whether to check the memory or not
     *
     * @var bool
     */
    protected $doCheckMemory = false;

    /**
     * Model construct for object initialization
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        $helper = $objectManager->get(\MagicToolbox\Sirv\Helper\Data::class);
        $this->isSirvEnabled = $helper->isSirvEnabled();
        $this->useSirvImageProcessing = $helper->useSirvImageProcessing();

        $this->sirvAdapter = $objectManager->get(\MagicToolbox\Sirv\Model\Adapter\S3::class);

        $this->viewAssetImageFactoryExists = property_exists('\Magento\Catalog\Model\Product\Image', 'viewAssetImageFactory');

        //NOTE: for versions 2.0.x (x >= 17), 2.1.6, 2.2.x (x >= 0)
        if ($this->viewAssetImageFactoryExists) {
            $this->mtViewAssetImageFactory = $objectManager->get(\MagicToolbox\Sirv\Model\View\Asset\ImageFactory::class);
            $this->mtViewAssetPlaceholderFactory = $objectManager->get(\Magento\Catalog\Model\View\Asset\PlaceholderFactory::class);
        }

        //NOTE: _construct method is called at the very end of the Magento\Framework\Model\AbstractModel class constructor
        //      at the time of the call, not all properties in the Magento\Catalog\Model\Product\Image class are set
        $filesystem = $objectManager->get(\Magento\Framework\Filesystem::class);
        $mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->mediaDirectoryAbsolutePath = $mediaDirectory->getAbsolutePath();

        //NOTE: memory check is not performed since version 2.2.4
        $this->doCheckMemory = method_exists($this, '_checkMemory');
    }

    /**
     * @return MagentoImage
     */
    public function getImageProcessor()
    {
        if (!$this->_processor) {
            parent::getImageProcessor();
        }
        /** @var \MagicToolbox\Sirv\Model\Image */
        return $this->_processor;
    }

    /**
     * Set filenames for base file and new file
     *
     * @param string $file
     * @return $this
     * @throws \Exception
     */
    public function setBaseFile($file)
    {
        if (!$this->isSirvEnabled) {
            return parent::setBaseFile($file);
        }

        if (!$this->viewAssetImageFactoryExists) {
            //NOTE: for versions 2.0.x (x < 17), 2.1.x (x != 6)
            return parent::setBaseFile($file);
        }

        $this->_isBaseFilePlaceholder = false;

        $this->mtImageAsset = $this->mtViewAssetImageFactory->create(
            [
                'miscParams' => $this->mtGetMiscParams(),
                'filePath' => $file,
            ]
        );

        if ($file == 'no_selection' || !$this->_fileExists($this->mtImageAsset->getSourceFile())
            || $this->doCheckMemory && !$this->_checkMemory($this->mtImageAsset->getSourceFile())
        ) {
            $this->_isBaseFilePlaceholder = true;
            $this->mtImageAsset = $this->mtViewAssetPlaceholderFactory->create(
                [
                    'type' => $this->getDestinationSubdir(),
                ]
            );
        }

        $this->_baseFile = $this->mtImageAsset->getSourceFile();

        //NOTE: fix path to placeholder
        if ($this->_isBaseFilePlaceholder) {
            $path = $this->mtImageAsset->getContext()->getPath();
            $relPath = $this->_catalogProductMediaConfig->getBaseMediaPath();
            $this->_baseFile = preg_replace('#^'.preg_quote($path, '#').'#', $relPath, $this->_baseFile);
        }

        return $this;
    }

    /**
     * Save image file
     *
     * @return $this
     */
    public function saveFile()
    {
        if (!$this->isSirvEnabled) {
            return parent::saveFile();
        }

        if ($this->viewAssetImageFactoryExists) {
            if ($this->_isBaseFilePlaceholder) {
                return $this;
            }
            $filename = $this->getBaseFile() ? $this->mtImageAsset->getPath() : null;
            if ($this->useSirvImageProcessing) {
                $_fileName = $this->_baseFile;
            } else {
                $mediaPath = $this->_mediaDirectory->getAbsolutePath();
                $_fileName = preg_replace('#^'.preg_quote($mediaPath, '#').'#', '', $filename);
            }

            try {
                $this->getImageProcessor()->save($_fileName);
            } catch (\Exception $e) {
                throw new \Exception('Could not save image file. '.$e->getMessage());
            }

            //NOTE: can't save file because it doesn't exist on filesystem
            //$this->_coreFileStorageDatabase->saveFile($filename);

            //NOTE: this class exists in version 2.1.6
            if (class_exists('\Magento\Catalog\Model\Product\Image\SizeCache')) {
                $this->mtGetSizeCache()->save(
                    $this->getWidth(),
                    $this->getHeight(),
                    $this->mtImageAsset->getPath()
                );
            }
        } else {
            //NOTE: for versions 2.0.x (x < 17), 2.1.x (x != 6)

            if ($this->_isBaseFilePlaceholder && $this->_newFile === true) {
                return $this;
            }
            $filename = $this->_mediaDirectory->getAbsolutePath($this->getNewFile());
            if ($this->useSirvImageProcessing) {
                $_fileName = $this->_baseFile;
            } else {
                $_fileName = $this->_newFile;
            }

            $this->getImageProcessor()->save($_fileName);

            //NOTE: can't save file because it doesn't exist on filesystem
            //$this->_coreFileStorageDatabase->saveFile($filename);

            return $this;
        }
        return $this;
    }

    /**
     * @return \Magento\Catalog\Model\Product\Image\SizeCache
     */
    protected function mtGetSizeCache()
    {
        if ($this->mtSizeCache == null) {
            $this->mtSizeCache = \Magento\Framework\App\ObjectManager::getInstance()->get(
                \Magento\Catalog\Model\Product\Image\SizeCache::class
            );
        }
        return $this->mtSizeCache;
    }

    /**
     * @return string
     */
    public function getUrl()
    {
        if (!$this->isSirvEnabled) {
            return parent::getUrl();
        }
        if ($this->viewAssetImageFactoryExists) {
            if ($this->_isBaseFilePlaceholder) {
                return $this->mtImageAsset->getUrl();
            }
            if ($this->useSirvImageProcessing) {
                $url = $this->sirvAdapter->getUrl($this->_baseFile);
                $url .= $this->getImageProcessor()->getImagingOptionsQuery();
            } else {
                $url = $this->mtImageAsset->getUrl();
                $mediaUrl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
                $url = preg_replace('#^'.preg_quote($mediaUrl, '#').'#', '', $url);
                $url = $this->sirvAdapter->getUrl($url);
            }
        } else {
            //NOTE: for versions 2.0.x (x < 17), 2.1.x (x != 6)

            if ($this->_newFile === true) {
                $url = $this->_assetRepo->getUrl(
                    "Magento_Catalog::images/product/placeholder/{$this->getDestinationSubdir()}.jpg"
                );
                return $url;
            }
            if ($this->useSirvImageProcessing) {
                $url = $this->sirvAdapter->getUrl($this->_baseFile);
                $url .= $this->getImageProcessor()->getImagingOptionsQuery();
            } else {
                $url = $this->sirvAdapter->getUrl($this->_newFile);
            }
        }
        return $url;
    }

    /**
     * @return bool|void
     */
    public function isCached()
    {
        if ($this->isSirvEnabled) {
            if ($this->useSirvImageProcessing) {
                $modificationTime = filemtime($this->mediaDirectoryAbsolutePath . $this->_baseFile);
                return $this->sirvAdapter->fileExists($this->_baseFile, $modificationTime);
            } else {
                if ($this->viewAssetImageFactoryExists) {
                    //NOTE: cached file absolute path
                    $filename = $this->mtImageAsset->getPath();
                    $sourceFilePath = $this->mediaDirectoryAbsolutePath.$this->mtImageAsset->getSourceFile();
                    //NOTE: cached image does not exist in FS? so we have to check original file
                    $modificationTime = filemtime($sourceFilePath);
                    //NOTE: cached file relative path
                    $filename = preg_replace('#^'.preg_quote($this->mediaDirectoryAbsolutePath, '#').'#', '', $filename);
                    return $this->sirvAdapter->fileExists($filename, $modificationTime);
                } else {
                    //NOTE: for versions 2.0.x (x < 17), 2.1.x (x != 6)
                    return $this->sirvAdapter->fileExists($this->_newFile);
                }
            }
        }
        return parent::isCached();
    }

    /**
     * Return resized product image information
     *
     * @return array
     */
    public function getResizedImageInfo()
    {
        if ($this->isSirvEnabled) {
            if ($this->viewAssetImageFactoryExists) {
                if ($this->isBaseFilePlaceholder() == true) {
                    $image = $this->mtImageAsset->getSourceFile();
                    return getimagesize($image);
                } else {
                    if ($this->useSirvImageProcessing) {
                        $filename = $this->mtImageAsset->getSourceFile();
                    } else {
                        $filename = $this->mtImageAsset->getPath();
                        $mediaPath = $this->_mediaDirectory->getAbsolutePath();
                        $filename = preg_replace('#^'.preg_quote($mediaPath, '#').'#', '', $filename);
                    }
                    //NOTE: when calling 'getImageInfo' function, the image is downloaded from the Sirv server
                    //      this results in a significant server load.
                    //return $this->sirvAdapter->getImageInfo($filename);
                    return $this->getImageProcessor()->getImageSize();
                }
            } else {
                //NOTE: for versions 2.0.x (x < 17), 2.1.x (x != 6)
                if ($this->_newFile !== true) {
                    if ($this->useSirvImageProcessing) {
                        $filename = $this->_baseFile;
                    } else {
                        $mediaPath = $this->_mediaDirectory->getAbsolutePath();
                        $filename = preg_replace('#^'.preg_quote($mediaPath, '#').'#', '', $this->_newFile);
                    }
                    //return $this->sirvAdapter->getImageInfo($filename);
                    return $this->getImageProcessor()->getImageSize();
                }
            }
        }
        return parent::getResizedImageInfo();
    }

    /**
     * @return \Magento\Catalog\Model\Product\Image\ParamsBuilder
     */
    protected function mtGetParamsBuilder()
    {
        if ($this->mtParamsBuilder == null) {
            $this->mtParamsBuilder = \Magento\Framework\App\ObjectManager::getInstance()->get(
                \Magento\Catalog\Model\Product\Image\ParamsBuilder::class
            );
        }
        return $this->mtParamsBuilder;
    }

    /**
     * Retrieve misc params based on all image attributes
     *
     * @return array
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    protected function mtGetMiscParams()
    {
        if (class_exists('\Magento\Catalog\Model\Product\Image\ParamsBuilder')) {
            //NOTE: this class exists in versions: 2.1.6, 2.3.0
            return $this->mtGetParamsBuilder()->build(
                [
                    'type' => $this->getDestinationSubdir(),
                    'width' => $this->getWidth(),
                    'height' => $this->getHeight(),
                    'frame' => $this->_keepFrame,
                    'constrain' => $this->_constrainOnly,
                    'aspect_ratio' => $this->_keepAspectRatio,
                    'transparency' => $this->_keepTransparency,
                    'background' => $this->_backgroundColor,
                    'angle' => $this->_angle,
                    'quality' => $this->_quality
                ]
            );
        } else {
            //NOTE: for version 2.2.x
            $miscParams = [
                'image_type' => $this->getDestinationSubdir(),
                'image_height' => $this->getHeight(),
                'image_width' => $this->getWidth(),
                'keep_aspect_ratio' => ($this->_keepAspectRatio ? '' : 'non') . 'proportional',
                'keep_frame' => ($this->_keepFrame ? '' : 'no') . 'frame',
                'keep_transparency' => ($this->_keepTransparency ? '' : 'no') . 'transparency',
                'constrain_only' => ($this->_constrainOnly ? 'do' : 'not') . 'constrainonly',
                'background' => $this->_rgbToString($this->_backgroundColor),
                'angle' => $this->_angle,
                'quality' => $this->_quality,
            ];
            if ($this->getWatermarkFile()) {
                $miscParams['watermark_file'] = $this->getWatermarkFile();
                $miscParams['watermark_image_opacity'] = $this->getWatermarkImageOpacity();
                $miscParams['watermark_position'] = $this->getWatermarkPosition();
                $miscParams['watermark_width'] = $this->getWatermarkWidth();
                $miscParams['watermark_height'] = $this->getWatermarkHeight();
            }
            return $miscParams;
        }
    }
}
