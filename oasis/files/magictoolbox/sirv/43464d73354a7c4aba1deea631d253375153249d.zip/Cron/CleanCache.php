<?php

namespace MagicToolbox\Sirv\Cron;

/**
 * Clean cache task
 *
 */
class CleanCache
{
    /**
     * Is Sirv enabled flag
     *
     * @var bool
     */
    protected $isSirvEnabled = false;

    /**
     * Use Sirv image processing flag
     *
     * @var bool
     */
    protected $useSirvImageProcessing = true;

    /**
     * Cache helper
     *
     * @var \MagicToolbox\Sirv\Helper\Cache
     */
    protected $cacheHelper = null;

    /**
     * Media directory absolute path
     *
     * @var string
     */
    protected $mediaDirectoryAbsolutePath = '';

    /**
     * Sirv adapter
     *
     * @var \MagicToolbox\Sirv\Model\Adapter\S3
     */
    protected $sirvAdapter = null;

    /**
     * @param \MagicToolbox\Sirv\Helper\Data $helper
     * @param \MagicToolbox\Sirv\Helper\Cache $cacheHelper
     * @param \Magento\Framework\Filesystem $filesystem
     * @param \MagicToolbox\Sirv\Model\Adapter\S3 $sirvAdapter
     * @param \Magento\Catalog\Model\Product\Media\Config $catalogProductMediaConfig
     */
    public function __construct(
        \MagicToolbox\Sirv\Helper\Data $helper,
        \MagicToolbox\Sirv\Helper\Cache $cacheHelper,
        \Magento\Framework\Filesystem $filesystem,
        \MagicToolbox\Sirv\Model\Adapter\S3 $sirvAdapter,
        \Magento\Catalog\Model\Product\Media\Config $catalogProductMediaConfig
    ) {
        $this->isSirvEnabled = $helper->isSirvEnabled();
        $this->useSirvImageProcessing = $helper->useSirvImageProcessing();
        $this->cacheHelper = $cacheHelper;
        $mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->mediaDirectoryAbsolutePath = $mediaDirectory->getAbsolutePath($catalogProductMediaConfig->getBaseMediaPath());
        $this->sirvAdapter = $sirvAdapter;
    }

    /**
     * Cron job method to clean all expired entries
     *
     * @param \Magento\Cron\Model\Schedule $schedule
     * @return $this
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function execute(\Magento\Cron\Model\Schedule $schedule)
    {
        $this->cleanCache();
        return $this;
    }

    /**
     * Find and delete all expired entries
     *
     */
    public function cleanCache()
    {
        if (!$this->isSirvEnabled || !$this->useSirvImageProcessing) {
            return;
        }

        $collection = $this->cacheHelper->getCacheCollection()->load();

        if ($collection->getSize() == 0) {
            return;
        }

        foreach ($collection->getIterator() as $record) {
            $url = $record->getData('url');
            $timestamp = $record->getData('modification_time');

            $filePath = $this->mediaDirectoryAbsolutePath . $url;

            if (!file_exists($filePath)) {
                //NOTE: file does not exist localy so remove it from sirv
                $this->sirvAdapter->remove($url);//NOTE: remove url (because of cache pathes)
                $record->delete();
                continue;
            }

            $modificationTime = filemtime($filePath);
            if ($timestamp < $modificationTime) {
                //NOTE: file was changed so reupload file to sirv
                $this->sirvAdapter->save($url, $filePath);
            }
        }
    }
}
