<?php
/**
 * Copyright 2019 aheadWorks. All rights reserved.
See LICENSE.txt for license details.
 */

namespace Aheadworks\Sarp2\Model\Quote\Address\Total;

use Magento\Quote\Model\Quote\Address\Total\AbstractTotal;

/**
 * Class Replacer
 * @package Aheadworks\Sarp2\Model\Quote\Address\Total
 */
class Replacer extends AbstractTotal
{
}
