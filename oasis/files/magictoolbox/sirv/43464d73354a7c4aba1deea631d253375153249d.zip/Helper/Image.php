<?php

namespace MagicToolbox\Sirv\Helper;

/**
 * Sirv image helper
 */
class Image extends \Magento\Catalog\Helper\Image
{
    /**
     * Determine if the data has been initialized or not
     *
     * @var bool
     */
    protected static $isInitialized = false;

    /**
     * Sirv config helper
     *
     * @var \MagicToolbox\Sirv\Helper\Data
     */
    protected static $sirvConfigHelper = null;

    /**
     * Is Sirv enabled flag
     *
     * @var bool
     */
    protected static $isSirvEnabled = false;

    /**
     * Initialize the data
     *
     * @return void
     */
    protected function initializeData()
    {
        static::$isInitialized = true;
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        static::$sirvConfigHelper = $objectManager->get(\MagicToolbox\Sirv\Helper\Data::class);
        static::$isSirvEnabled = static::$sirvConfigHelper->isSirvEnabled();
    }

    /**
     * Check if scheduled actions is allowed
     *
     * @return bool
     */
    protected function isScheduledActionsAllowed()
    {
        if (static::$isInitialized === false) {
            $this->initializeData();
        }

        if (parent::isScheduledActionsAllowed()) {
            return true;
        } elseif (static::$isSirvEnabled) {
            $model = $this->_getModel();
            if (property_exists('\Magento\Catalog\Model\Product\Image', 'viewAssetImageFactory')) {
                if ($model->isBaseFilePlaceholder()) {
                    return false;
                }
            } else {
                if ($model->isBaseFilePlaceholder() && $model->getNewFile() === true) {
                    return false;
                }
            }
            return true;
        } else {
            return false;
        }
    }
}
