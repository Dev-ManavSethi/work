<?php

namespace MagicToolbox\Sirv\Controller\Adminhtml\Ajax;

/**
 * Synchronize media ajax controller
 *
 */
class Synchronize extends \MagicToolbox\Sirv\Controller\Adminhtml\Settings
{
    /**
     * Config helper
     *
     * @var \MagicToolbox\Sirv\Helper\Data
     */
    protected $configHelper = null;

    /**
     * Cache helper
     *
     * @var \MagicToolbox\Sirv\Helper\Cache
     */
    protected $cacheHelper = null;

    /**
     * Sirv adapter factory
     *
     * @var \MagicToolbox\Sirv\Model\Adapter\S3Factory
     */
    protected $s3Factory = null;

    /**
     * Sirv adapter
     *
     * @var \MagicToolbox\Sirv\Model\Adapter\S3
     */
    protected $sirvAdapter = null;

    /**
     * Gallery model factory
     *
     * @var \MagicToolbox\Sirv\Model\GalleryFactory
     */
    protected $galleryFactory = null;

    /**
     * Base media path
     *
     * @var string
     */
    protected $baseMediaPath = '';

    /**
     * Absolute base media path
     *
     * @var string
     */
    protected $absBaseMediaPath = '';

    /**
     * How many images to synchronize with one request
     *
     * @var integer
     */
    protected $pageSize = 10;

    /**
     * Constructor
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \MagicToolbox\Sirv\Helper\Data $configHelper
     * @param \MagicToolbox\Sirv\Helper\Cache $cacheHelper
     * @param \MagicToolbox\Sirv\Model\Adapter\S3Factory $s3Factory
     * @param \MagicToolbox\Sirv\Model\GalleryFactory $galleryFactory
     * @param \Magento\Framework\Filesystem $filesystem
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \MagicToolbox\Sirv\Helper\Data $configHelper,
        \MagicToolbox\Sirv\Helper\Cache $cacheHelper,
        \MagicToolbox\Sirv\Model\Adapter\S3Factory $s3Factory,
        \MagicToolbox\Sirv\Model\GalleryFactory $galleryFactory,
        \Magento\Framework\Filesystem $filesystem
    ) {
        parent::__construct($context, $resultPageFactory);
        $this->configHelper = $configHelper;
        $this->cacheHelper = $cacheHelper;
        $this->s3Factory = $s3Factory;
        $this->galleryFactory = $galleryFactory;
        $mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->baseMediaPath = $this->cacheHelper->getBaseMediaPath();
        $this->absBaseMediaPath = $mediaDirectory->getAbsolutePath($this->baseMediaPath);
    }

    /**
     * Save action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        $action = isset($data['dataAction']) ? $data['dataAction'] : '';

        $result = ['error' => false];

        switch ($action) {
            case 'get_data':
                $data = $this->getMediaGalleryData();
                $result = array_merge($result, $data);
                break;
            case 'synchronize':
                $this->configHelper->loadConfig();

                if (!$this->configHelper->useSirvImageProcessing()) {
                    //NOTE: we can't synchronize media gallery in this case because cached files don't exist in file system
                    $result['error'] = __(
                        'Synchronization media is not possible when "Optimize from originals" option is disabled because cached files don\'t exist in file system'
                    );
                    break;
                }

                $this->sirvAdapter = $this->s3Factory->create([
                    'helper' => $this->configHelper,
                    'cacheHelper' => $this->cacheHelper
                ]);

                if (!$this->sirvAdapter->isAuth()) {
                    $result['error'] = __(
                        'The access identifiers you provided for Sirv were denied. You must enter proper credentials to use Sirv.'
                    );
                    break;
                }

                /** @var int $maxNumberOfImages Number of images left to sync */
                /**/
                $maxNumberOfImages = isset($data['maxNumberOfImages']) ? (int)$data['maxNumberOfImages'] : 0;
                $data = $this->synchronizeMediaGallery($maxNumberOfImages);
                /*
                $pageNumber = isset($data['currentPage']) ? (int)$data['currentPage'] : 1;
                $collectionSize = isset($data['totalItems']) ? (int)$data['totalItems'] : 0;
                $data = $this->synchronizeMediaGalleryByPage($pageNumber, $collectionSize);
                /**/

                $result = array_merge($result, $data);
                break;
            default:
                break;
        }

        /** @var \Magento\Framework\Controller\Result\Json $resultJson */
        $resultJson = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_JSON);
        $resultJson->setData($result);
        return $resultJson;
    }

    /**
     * Method to get media gallery data
     *
     * @return array
     */
    protected function getMediaGalleryData()
    {
        $data = [];

        $galleryModel = $this->galleryFactory->create();
        $collection = $galleryModel->getCollection();

        $collection->addFieldToFilter('media_type', [
            'image',
            'external-video',
        ]);
        $collection->addFieldToFilter('disabled', '0');
        $collection->addFieldToFilter('value', ['notnull' => true]);
        $collection->addFieldToFilter('value', ['neq' => '']);

        $collection->addFieldToSelect('value');

        //NOTE: to get the proper query for unique values
        //      SELECT COUNT(DISTINCT value) FROM `catalog_product_entity_media_gallery` AS `main_table` WHERE (`media_type` = 'image') AND (`disabled` = '0')
        $collection->getSelect()->group('value');
        //$collection->distinct(true);

        $data['total'] = $collection->getSize();

        $cacheCollection = $this->cacheHelper->getCacheCollection();
        $cacheCollection->addFieldToFilter('url', ['nlike' => '/watermark/%']);
        $data['cached'] = $cacheCollection->getSize();

        return $data;
    }

    /**
     * Method to synchronize media gallery
     *
     * @return array
     */
    protected function synchronizeMediaGallery($maxNumberOfImages)
    {
        $startTime = time();
        $maxExecutionTime = (int)ini_get('max_execution_time');
        if (!$maxExecutionTime) {
            $maxExecutionTime = 60;
        }
        //NOTE: 10 seconds to complete
        $breakTime = $maxExecutionTime + $startTime - 10;

        $data = [
            'completed' => false,
            'aborted' => false,
            'nonexistentFiles' => [],
            'cached' => 0,
            'uploaded' => 0,
        ];

        /** @var \Magento\Backend\Model\Session $session */
        $session = $this->_getSession();
        $sessionData = $session->getData();
        if (isset($sessionData['sirv'], $sessionData['sirv']['nonexistent-files'])) {
            $data['nonexistentFiles'] = $sessionData['sirv']['nonexistent-files'];
        } else {
            $session->setSirv(['nonexistent-files' => []]);
        }

        if ($maxNumberOfImages < 1) {
            $data['aborted'] = true;
            $data['completed'] = true;
            return $data;
        }

        $galleryModel = $this->galleryFactory->create();
        $collection = $galleryModel->getCollection();

        $collection->addFieldToSelect('value');

        $collection->addFieldToFilter('media_type', [
            'image',
            'external-video',
        ]);
        $collection->addFieldToFilter('disabled', '0');
        $collection->addFieldToFilter('value', ['notnull' => true]);
        $collection->addFieldToFilter('value', ['neq' => '']);

        $cacheTable = $this->cacheHelper->getCacheTable();
        //NOTICE: because of the modifications of Magento code (modules etc.),
        //        the url in the media table may or may not contain the previous slash,
        //        this can lead to the wrong result of the request
        //$collection->getSelect()->where('`value` NOT IN(SELECT `url` FROM `' . $cacheTable . '`)');
        $collection->getSelect()->where('CONCAT("/", TRIM(LEADING "/" FROM `value`)) NOT IN(SELECT `url` FROM `' . $cacheTable . '`)');

        if (!empty($data['nonexistentFiles'])) {
            $set = '"' . implode('", "', $data['nonexistentFiles']) . '"';
            $collection->getSelect()->where('CONCAT("/", TRIM(LEADING "/" FROM `value`)) NOT IN(' . $set . ')');
        }

        $collection->getSelect()->group('value');

        $collection->getSelect()->limit($this->pageSize);

        $items = $collection->getData();

        $count = 0;
        foreach ($items as $item) {
            $count++;
            $item['value'] = '/' . ltrim($item['value'], '/');
            $absolutePath = $this->absBaseMediaPath . $item['value'];

            if (!is_file($absolutePath)) {
                $data['nonexistentFiles'][] = $item['value'];
                continue;
            }

            $modificationTime = filemtime($absolutePath);

            $path = $this->baseMediaPath . $item['value'];

            //NOTE: this will check for file in the cache
            //      or on the Sirv server if the file does not exist in the cache
            if ($this->sirvAdapter->fileExists($path, $modificationTime)) {
                $data['cached']++;
            } else {
                if ($this->sirvAdapter->save($path, $absolutePath)) {
                    //NOTE: http code 200
                    $data['cached']++;
                    $data['uploaded']++;
                    if ($data['uploaded'] >= $maxNumberOfImages) {
                        $data['aborted'] = true;
                        break;
                    }
                }
            }

            if ($breakTime - time() <= 0) {
                $data['aborted'] = true;
                break;
            }
        }

        $session->setSirv(['nonexistent-files' => $data['nonexistentFiles']]);

        if (!$count) {
            $data['completed'] = true;
        }

        return $data;
    }

    /**
     * Method to synchronize media gallery
     *
     * @return array
     */
    protected function synchronizeMediaGalleryByPage($pageNumber, $collectionSize)
    {
        $startTime = time();
        $maxExecutionTime = (int)ini_get('max_execution_time');
        if (!$maxExecutionTime) {
            $maxExecutionTime = 60;
        }
        //NOTE: 10 seconds to complete
        $breakTime = $maxExecutionTime + $startTime - 10;

        $data = [
            'page' => $pageNumber,
            'completed' => false,
            'aborted' => false,
            'nonexistentFiles' => 0,
            'uploaded' => 0,
        ];

        if (!$collectionSize) {
            $data['aborted'] = true;
            $data['completed'] = true;
            return $data;
        }

        $lastPageNumber = ceil($collectionSize/$this->pageSize);

        if ($pageNumber > $lastPageNumber) {
            $data['completed'] = true;
            return $data;
        }

        $galleryModel = $this->galleryFactory->create();
        $collection = $galleryModel->getCollection();

        $collection->addFieldToFilter('media_type', [
            'image',
            'external-video',
        ]);
        $collection->addFieldToFilter('disabled', '0');
        $collection->addFieldToFilter('value', ['notnull' => true]);
        $collection->addFieldToFilter('value', ['neq' => '']);

        $collection->addFieldToSelect('value');

        $collection->getSelect()->group('value');
        //$collection->distinct(true);

        $collection->setPageSize($this->pageSize);
        $collection->setCurPage($pageNumber);

        $items = $collection->getData();

        $count = 0;
        foreach ($items as $item) {
            $count++;

            $item['value'] = '/' . ltrim($item['value'], '/');

            $absolutePath = $this->absBaseMediaPath . $item['value'];
            if (!is_file($absolutePath)) {
                $data['nonexistentFiles']++;
                continue;
            }

            $path = $this->baseMediaPath . $item['value'];
            //NOTE: this will check for file in the cache
            //      or on the Sirv server if the file does not exist in the cache
            if (!$this->sirvAdapter->fileExists($path)) {
                if ($this->sirvAdapter->save($path, $absolutePath)) {
                    //NOTE: http code 200
                    $data['uploaded']++;
                }
            }

            if ($breakTime - time() <= 0) {
                $data['aborted'] = true;
                break;
            }
        }

        if (!$count) {
            $data['completed'] = true;
        }

        return $data;
    }
}
