<?php
/**
 * Copyright 2019 aheadWorks. All rights reserved.
See LICENSE.txt for license details.
 */


return [
    [5, 'braintree', 'card', 'token-value-1', '2018-06-26 11:32:41', '2026-07-01 00:00:00', 1],
    [6, 'braintree', 'card', 'token-value-2', '2018-06-26 11:39:53', '2026-09-01 00:00:00', 1]
];
