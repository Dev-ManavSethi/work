<?php

namespace MagicToolbox\Sirv\Model\ResourceModel\Gallery;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('MagicToolbox\Sirv\Model\Gallery', 'MagicToolbox\Sirv\Model\ResourceModel\Gallery');
    }
}
