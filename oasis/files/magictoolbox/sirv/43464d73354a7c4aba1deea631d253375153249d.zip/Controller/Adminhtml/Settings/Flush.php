<?php

namespace MagicToolbox\Sirv\Controller\Adminhtml\Settings;

class Flush extends \MagicToolbox\Sirv\Controller\Adminhtml\Settings
{
    /**
     * Config helper
     * @var \MagicToolbox\Sirv\Helper\Data
     */
    protected $configHelper = null;

    /**
     * Cache helper
     * @var \MagicToolbox\Sirv\Helper\Cache
     */
    protected $cacheHelper = null;

    /**
     * Constructor
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \MagicToolbox\Sirv\Helper\Data $configHelper
     * @param \MagicToolbox\Sirv\Helper\Cache $cacheHelper
     * @param \MagicToolbox\Sirv\Model\Adapter\S3Factory $s3Factory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \MagicToolbox\Sirv\Helper\Data $configHelper,
        \MagicToolbox\Sirv\Helper\Cache $cacheHelper
    ) {
        parent::__construct($context, $resultPageFactory);
        $this->configHelper = $configHelper;
        $this->cacheHelper = $cacheHelper;
    }

    /**
     * Save action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        try {
            $this->configHelper->loadConfig();

            //NOTE: clear all images from the Sirv extension database cache
            $this->cacheHelper->clearCache();

            $this->messageManager->addSuccess(__('The image cache was cleaned.'));
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addError($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addException($e, __('An error occurred while clearing the image cache.'));
        }

        $resultRedirect->setPath('sirv/*/edit');

        return $resultRedirect;
    }
}
